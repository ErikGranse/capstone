/*
 * Vent.java
 *
 * Created on June 20, 2005, 9:46 PM
 *
 */

/**
 *
 * @author egranse
 */

import java.util.*;

public class Vent {
        private Beat beat;
        private List listeners = new ArrayList();
	public int interval = 1000;
	public int interval2 = 200;
	public volatile boolean var = false;
	int time;
	int time3;
	Thread A, B;

	public Vent()
        {
		Runnable runA = new Runnable()
                {
			public void run()
                        {
	   			runWork();
	 		}
		};
		A = new Thread(runA, "threadA");
		A.start();
	}

	public void runWork()
        {
		int time2;
		time = (int)System.currentTimeMillis();
		while(true)
		{
			try
                        {
                            while(true)
                            {
				time3 = (int)System.currentTimeMillis() - time;
                                System.out.println("before sleep " + (time3));
                                beat = Beat.BEAT;
                                fireBeatEvent();
				Thread.sleep(interval);
				if(!var)
				break;
                            }
                        }
                        catch(Exception e)
                        {
                        }
                        if(!var)
                        {
                            time2 = (int)(System.currentTimeMillis() - time);
                            System.out.println("after sleep " + time2 + "\n");
                            var = true;
                            Runnable runB = new Runnable()
                            {
                                public void run()
                                {
                                    runWork2();
				}
			};
			Thread B = new Thread(runB, "threadB");
                        B.start();
                    }
                }
	}
	public void runWork2()
	{
		try{
			int refTime = (int)(System.currentTimeMillis() - time);
			System.out.println("Refractory time started = " + refTime);
                        beat = Beat.R_START;
                        fireBeatEvent();
			Thread.sleep(interval2);
			refTime = (int)(System.currentTimeMillis() - time);
			System.out.println("Refractory time elapsed = " + refTime);
                        beat = Beat.R_START;
                        fireBeatEvent();
			var = false;
		}catch(Exception e){
		}
	}
        
        public synchronized void addBeatListener(BeatListener bl) {
            listeners.add(bl);
        }
    
        public synchronized void removeBeatListener(BeatListener bl) {
            listeners.remove(bl);
        }
    
        private synchronized void fireBeatEvent() {
        BeatEvent beatEvent = new BeatEvent(this, beat);
        Iterator listenerIterator = listeners.iterator();
        while(listenerIterator.hasNext()) {
            ((BeatListener) listenerIterator.next()).beatSensed(beatEvent);
        }
    }
        
	public static void main(String[] args) {
	  Vent myVent = new Vent();
	}
} 