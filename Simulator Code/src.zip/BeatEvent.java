/*
 * BeatEvent.java
 *
 * Created on June 20, 2005, 10:13 PM
 *
 * This is the object that will be returned to the listener; it contains a reference
 * to the source object and a beat object that will expose the type of beat event.
 */

/**
 *
 * @author egranse
 */
import java.util.EventObject;

public class BeatEvent extends EventObject {
    
    private Beat beat;
    
    public BeatEvent(Object source, Beat beat) {
        super(source);
        this.beat = beat;
    }

    public Beat beat() {
        return beat;
    }
    
}