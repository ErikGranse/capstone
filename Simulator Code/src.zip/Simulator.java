/*
 * simulator.java
 *
 * Created on June 20, 2005, 11:15 PM
 *
 * The main file for the project.
 */

/**
 *
 * @author egranse
 */
public class Simulator {

    public static void main( String [] args ) {
        BeatListener monitor = new HeartMonitor();
        
        //We will probably have to include a start() method in the vent; right
        //now, creating the object starts the timers before the listener is added.
        Vent vent = new Vent();
        vent.addBeatListener(monitor);
    } 

}
