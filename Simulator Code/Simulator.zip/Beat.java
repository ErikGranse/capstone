/*
 * Beat.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Beat object that will be passed via the BeatEvent object. Creates static Beat
 * objects for easy reference.
 */

/**
 *
 * @author egranse
 */

public class Beat {

    /** Creates a new instance of Beat */
    public Beat() {
    }

    public static final Beat BEAT = new Beat("Beat");
    public static final Beat R_START = new Beat("rStart");
    public static final Beat R_END = new Beat("rEnd");

    private String beat;

    public String toString() {
        return beat;
    }

    private Beat(String beat) {
        this.beat = beat;
    }

}