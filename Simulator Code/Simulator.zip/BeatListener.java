/*
 * BeatListener.java
 *
 * Created on June 20, 2005, 10:20 PM
 *
 * Duh.
 */

/**
 *
 * @author egranse
 */

public interface BeatListener {
    public void beatSensed(BeatEvent event);
}

