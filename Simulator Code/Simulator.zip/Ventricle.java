/*
 * Vent.java
 *
 * Created on June 20, 2005, 9:46 PM
 *
 */

/**
 *
 * @author egranse
 */

import java.util.*;

public class Ventricle {
    private Beat beat;
    private List listeners = new ArrayList();
    public int interval = 1000;
    public int refInterval = 200;
    public volatile boolean var = false;
    int initialSystemTime;
    int startSleepTime;
    Thread A, B;

    public Ventricle() {
        Runnable runA = new Runnable() {
            public void run() {
                runWork();
            }
        };
        A = new Thread(runA, "Ventricle_Thread");
        A.start();
    }

    public void runWork() {
        int endSleepTime;
        initialSystemTime = (int) System.currentTimeMillis();
        while ( true ) {
            try {
                while ( true ) {
                    startSleepTime = (int) System.currentTimeMillis() 
                                        - initialSystemTime;
                    System.out.println(
                        "Ventricle interval started at: " 
                            + startSleepTime + " ms");
                    beat = Beat.BEAT;
                    fireBeatEvent();
                    Thread.sleep(interval);
                    if ( !var ) break;
                }
            } catch ( Exception e ) {
            }
            if ( !var ) {
                endSleepTime = (int) (System.currentTimeMillis() 
                                    - initialSystemTime);
                System.out.println("" +
                        "Ventricle interval ended at: " 
                            + endSleepTime + " ms\n");
                var = true;
                Runnable runB = new Runnable() {
                    public void run() {
                        runWork2();
                    }
                };
                Thread B = new Thread(runB, "Refractory_Thread");
                B.start();
            }
        }
    }

    public void runWork2() {
        try {
            int refTime = (int) (System.currentTimeMillis() - initialSystemTime);
            System.out.println("Refractory time started at: " + refTime + " ms");
            beat = Beat.R_START;
            fireBeatEvent();
            Thread.sleep(refInterval);
            refTime = (int) (System.currentTimeMillis() - initialSystemTime);
            System.out.println("Refractory time ended at: " + refTime + " ms");
            beat = Beat.R_START;
            fireBeatEvent();
            var = false;
        } catch ( Exception e ) {
        }
    }

    public synchronized void addBeatListener(BeatListener bl) {
        listeners.add(bl);
    }

    public synchronized void removeBeatListener(BeatListener bl) {
        listeners.remove(bl);
    }

    private synchronized void fireBeatEvent() {
        BeatEvent beatEvent = new BeatEvent(this, beat);
        Iterator listenerIterator = listeners.iterator();
        while ( listenerIterator.hasNext() ) {
            ((BeatListener) listenerIterator.next()).beatSensed(beatEvent);
        }
    }
}
