/*
 * HeartMonitor.java
 *
 * Created on June 20, 2005, 11:11 PM
 *
 * Will eventually be responsible for logging and writing to the display (or at
 * least call the appropriate objects to do so). Right now the code is stubbed
 * to just write a line to the command window.
 */

/**
 *
 * @author egranse
 */

public class HeartMonitor implements BeatListener {

    public void beatSensed(BeatEvent event) {
        if ( event.beat() == Beat.BEAT ) {
            System.out.println("Beat Sensed");
        } else if ( event.beat() == Beat.R_START ) {
            System.out.println("Refractory started");
        } else {
            System.out.println("Refractory ended");
        }
    }

}
