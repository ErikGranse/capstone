/*
 * Device.java
 *
 * Created on July 6, 2005, 2:00 PM
 *
 * The device is responsible for monitoring the heart and pacing appropriately.
 * Currently this class is missing methods; it's configured for VOO mode (pace
 * only) and does not watch the heart for intrinsic events.
 */

/**
 *
 * @author egranse
 */
import java.util.*;

public class Device{
	private boolean deviceInRefractory = false;
	private int deviceInterval = 1500;
	private int startTime;
	private Heart myHeart;
	Thread D, E;
	Runnable runD, runE;

	public Device(Heart aHeart)
	{
		myHeart = aHeart;
		runD = new Runnable()
		{
			public void run()
			{
				runWork4();
			}
		};

		// Defines thread D and associates it with runA
		// then starts up thread D
		D = new Thread(runD, "threadD");
		D.start();
	}
	public void runWork4()
	{
		int time3 = 0;
		while(true)
		{
			try
			{
				while(true)
				{
					time3 = (int)System.currentTimeMillis();
					System.out.println("Device before sleep 0");
					D.sleep(deviceInterval);
					if(!deviceInRefractory)
							break;
				}

			}
					catch(Exception e){ }
			if(!deviceInRefractory)
			{
				int time2 = (int)(System.currentTimeMillis() - time3);
				System.out.println("Device after sleep " + time2 + "\n");
				deviceBeat();
			}
		}
	}
	public void deviceBeat()
	{
		myHeart.beat();
		System.out.println("Device beating");
		deviceInRefractory = true;
		deviceRefractory();
	}
	public void deviceRefractory()
	{
		runE = new Runnable()
		{
			public void run()
			{
				runWork5();
			}
		};

		// Defines thread D and associates it with runA
		// then starts up thread D
		E = new Thread(runE, "threadE");
		E.start();
	}
	public void runWork5()
	{
		try
		{
		E.sleep(100);
		deviceInRefractory = false;
		}
			catch(Exception e){ }
	}
}