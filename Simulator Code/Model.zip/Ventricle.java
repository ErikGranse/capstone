/*
 * Ventricle.java
 *
 * Created on July 6, 2005, 2:02 PM
 *
 * The ventricle has been dumbed-down; it now receives a call to beat() and then
 * sets a refractory timer. Beat timing is handled by the AvlNode. 
 */

/**
 *
 * @author egranse
 */
import java.util.*;

public class Ventricle{
	private Thread A;
	private Runnable runA;
	private Thread C;
	private Runnable runC;
	private int time3;
	private int ventInterval = 2000;
	private volatile boolean inRefractory = false;

	public Ventricle()
	{
		// Defines runA and states that when it is run
		// it calls runWork
		runA = new Runnable()
		{
			public void run()
			{
				runWork();
			}
		};

		// Defines thread A and associates it with runA
		// then starts up thread A
		A = new Thread(runA, "threadA");
		A.start();
	}
	public void runWork(){
		while(true)
		{
			try
			{
				while(true)
				{
					time3 = (int)System.currentTimeMillis();
					System.out.println("ventricle before sleep 0");
					A.sleep(ventInterval);
					if(!inRefractory)
						break;
				}

			}
			catch(Exception e){ }
			if(!inRefractory)
			{
				int time2 = (int)(time3 - System.currentTimeMillis() );
				System.out.println("ventricle after sleep " + time2 + "\n");
				beat();

			}
		}
	}
	public synchronized void beat(){
		System.out.println("Vent beating");
		refractoryPeriod();
	}
	public synchronized void refractoryPeriod()
	{
		A.interrupt();
		runC = new Runnable()
		{
			public void run()
			{
				runWork3();
			}
		};

		// Defines thread A and associates it with runA
		// then starts up thread A
		C = new Thread(runC, "threadC");
		C.start();
	}
	public void runWork3()
	{
		System.out.println("Ventricle in refractory");
		try
		{
			C.sleep(100);
			inRefractory = false;
		}
		catch(Exception e){ }
		System.out.println("Ventricle out of refractory");

	}
	public synchronized boolean inRefract()
	{
		return inRefractory;
	}
	public void setRefractory()
	{
		inRefractory = true;
	}
}