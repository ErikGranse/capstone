/*
 * Simulator.java
 *
 * Created on July 6, 2005, 2:03 PM
 *
 */

/**
 *
 * @author egranse
 */
import java.util.*;


public class Simulator{
	public Simulator()
	{
		Heart myHeart = new Heart();
		Device myDevice = new Device(myHeart);
	}


	public static void main(String[] args)
	{
		Simulator mySimulator = new Simulator();
	}
}