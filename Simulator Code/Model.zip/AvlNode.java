/*
 * AvlNode.java
 *
 * Created on July 6, 2005, 2:02 PM
 *
 * The AvlNode is responsible for creating the intrinsic events which cause a
 * chamber to contract.
 */

/**
 *
 * @author egranse
 */
import java.util.*;

public class AvlNode{
	private Ventricle myVent;
	public Thread B;
	private Runnable runB;
	private int time3;
	private int avlInterval = 800;

	public AvlNode(Ventricle aVent)
	{
		myVent = aVent;
		runB = new Runnable()
		{
			public void run()
			{
				runWork2();
			}
		};

		// Defines thread A and associates it with runA
		// then starts up thread A
		B = new Thread(runB, "threadB");
		B.start();
	}
	public void runWork2()
	{
		while(true)
		{
			int timeLeft = avlInterval;
			try
			{
				while(timeLeft > 0)
				{
					time3 = (int)System.currentTimeMillis();
					System.out.println("AvlNode before sleep " + (time3));
					B.sleep(timeLeft);
					timeLeft = timeLeft + (time3 - (int)(System.currentTimeMillis()));
					System.out.println(timeLeft);
				}

			}
			catch(Exception e){ }
//			if(!inRefractory)
//			{
				int time2 = (int)(System.currentTimeMillis() - time3);
				System.out.println("AvlNode after sleep " + time2 + "\n");
				beat();

//			}
		}
	}
	public void beat(){
			System.out.println("AvlNode sent pulse");
			if(!myVent.inRefract())
			{
				myVent.setRefractory();
				myVent.beat();
			}
	}

}