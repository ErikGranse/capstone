/*
 * Heart.java
 *
 * Created on July 6, 2005, 2:03 PM
 *
 *The heart class is a controller for the model which is comprised of AvlNodes and Ventricles. 
 *The class is responsible for object creation within the model and message handling.
 */

/**
 *
 * @author egranse
 */
import java.util.*;

public class Heart{
	private AvlNode myAvlNode;
	private Ventricle myVent;
	public Heart()
	{
		myVent = new Ventricle();
		myAvlNode = new AvlNode(myVent);
	}
	public boolean inRefract()
	{
		return myVent.inRefract();
	}
	public void beat()
	{
		if(!inRefract())
			myVent.setRefractory();
			myAvlNode.B.interrupt();
			myVent.beat();

	}
}