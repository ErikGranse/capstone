import java.util.*;

public class Device implements BeatListener{
    private Pace pace;
    private Mode mode;
    
    private List listeners = new ArrayList();
	
    private boolean deviceInRefractory = false;
	
    private boolean inMaxPaceInterval = false;
	private boolean resetBySense = false;
	private boolean maxRatePace = false;
	private boolean triggeredPace = false;
	
	private volatile int deviceEscapeInterval = 10000;
	private volatile int deviceRefractoryInterval = 100;
	private volatile int deviceMaxPaceInterval = 400; // 400ms = 150 BPM
	
	private Ventricle myHeart;
	private Thread deviceEscapeThread, deviceRefractoryThread, deviceMaxPaceThread;
	private Runnable runDeviceEscape, runDeviceRefractory, runMaxPace;

	public Device(Ventricle aHeart){
		mode = Mode.VVI;
		myHeart = aHeart;
		runDeviceEscape = new Runnable(){
			public void run(){
				devicePace();
			}
		};
		deviceEscapeThread = new Thread(runDeviceEscape, "deviceEscapeThread");
		deviceEscapeThread.start();
	}

	public void devicePace(){
		while(true){
			try{
				while(true){
					deviceEscapeThread.sleep(deviceEscapeInterval);
					if(inMaxPaceInterval)
						maxRatePace = true;
					else break;
				}
			}
			catch(Exception e){ }
			
			
			if((mode == Mode.VVT && triggeredPace) || (!inMaxPaceInterval && !resetBySense)){
				if(maxRatePace){
					pace = Pace.MAX_PACE;
					maxRatePace = false;
				}
				else if(triggeredPace){
					pace = Pace.TRIGGERED_PACE;
					triggeredPace = false;
				}
				else
					pace = Pace.ESC_PACE;
				firePaceEvent();
				deviceBeat();
				System.out.println(mode.toString());
			}
			 resetBySense = false;
		}
	}
	
	public void deviceBeat(){
		myHeart.beat();
		inMaxPaceInterval = true;
		runMaxPace = new Runnable(){
			public void run(){
				startMaxPaceInterval();
			}
		};
		deviceMaxPaceThread = new Thread(runMaxPace, "MaxPaceRateThread");
		deviceMaxPaceThread.start();
	}
	
	public void startMaxPaceInterval(){
		try{
			deviceMaxPaceThread.sleep(deviceMaxPaceInterval);
		}
		catch(Exception e){}
		inMaxPaceInterval = false;
		if(maxRatePace){
			deviceEscapeThread.interrupt();
		}
	}

	public void deviceRefractory(){
		runDeviceRefractory = new Runnable(){
			public void run(){
				startDeviceRefractory();
			}
		};
		deviceRefractoryThread = new Thread(runDeviceRefractory, "threaddeviceRefractoryThread");
		deviceRefractoryThread.start();
	}

	public void startDeviceRefractory(){
		try{
			pace = Pace.R_START;
			firePaceEvent();
			deviceRefractoryThread.sleep(deviceRefractoryInterval);
			pace = Pace.R_END;
			firePaceEvent();
			deviceInRefractory = false;
		}
		catch(Exception e){ }
	}
	
    public void beatSensed(BeatEvent event) {
       if(event.beat == Beat.BEAT && mode != Mode.V00){
    	   if(!deviceInRefractory){
    		   resetBySense = true;
    		   deviceEscapeThread.interrupt();
    	   }
    	   deviceInRefractory = true;
    	   deviceRefractory();
    	   pace = Pace.SENSE;
    	   firePaceEvent();
    	   if(mode == Mode.VVT){
    		   triggeredPace = true;
    		   deviceEscapeThread.interrupt();
    	   }
       }
    }

	public synchronized void setMode(String newMode){
		if(newMode.equalsIgnoreCase("VOO")) {
			mode = Mode.V00;
		}
		else if(newMode.equalsIgnoreCase("VVI")) {
			mode = Mode.VVI;
		}
		else if(newMode.equalsIgnoreCase("VVT")) {
			mode = Mode.VVT;
		}
		System.out.println(mode.toString());
		System.out.println(newMode);
	}
	
	public synchronized String getMode(){
		return mode.toString();
	}
	
	public synchronized void setDeviceEscapeInterval(int newTime){
		deviceEscapeInterval = newTime;
	}
	
	public synchronized int getDeviceEscapeInterval(){
		return deviceEscapeInterval;
	}

	public synchronized void setDeviceRefractoryInterval(int newTime){
		deviceRefractoryInterval = newTime;
	}
	
	public synchronized int getDeviceRefractoryInterval(){
		return deviceRefractoryInterval;
	}
	
	public synchronized void setDeviceMaxPaceInterval(int newTime){
		deviceMaxPaceInterval = newTime;
	}
    
	public synchronized int getDeviceMaxPaceInterval(){
		return deviceMaxPaceInterval;
	}
	
	public synchronized void addPaceListener(PaceListener pl) {
        listeners.add(pl);
    }

    //Removes a listener from the listener list.
    public synchronized void removePaceListener(PaceListener pl) {
        listeners.remove(pl);
    }

    //Loops through all listeners and pushes the paceEvent to them.
    private synchronized void firePaceEvent() {
        PaceEvent paceEvent = new PaceEvent(this, pace);
        Iterator listenerIterator = listeners.iterator();
        while ( listenerIterator.hasNext() ) {
            ((PaceListener) listenerIterator.next()).paceSensed(paceEvent);
        }
    }
}
