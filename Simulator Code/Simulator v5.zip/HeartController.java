import java.util.*;

public class HeartController{
	protected AvlNode myAvlNode;
	protected Ventricle myVent;
	public HeartController()
	{
		myVent = new Ventricle();

		myAvlNode = new AvlNode(myVent);
	}
	public boolean inRefract()
	{
		return myVent.inRefract();
	}
	public void beat()
	{
		if(!inRefract())
		{
			myVent.setRefractory();
			myAvlNode.AvlThread.interrupt();
			myVent.beat();
		}

	}
}