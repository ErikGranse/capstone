
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Simulator implements ActionListener{
	HeartController myHeart;
	Device myDevice;
	public JTextField hInterval, rInterval, pInterval, avlInterval, drInterval;
    public JButton actionButton;

	public Simulator()
	{
		myHeart = new HeartController();

		myDevice = new Device(myHeart);
	}







    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        Simulator mySimulator = new Simulator();
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private void buildUI(Container container) {
        container.setLayout(new BoxLayout(container, BoxLayout.PAGE_AXIS));

        HeartMonitor monitor = new HeartMonitor();

        //We will probably have to include a start() method in the vent; right
        //now, creating the object starts the timers before the listener is added.
		myHeart.myVent.addBeatListener(monitor);
		myDevice.addPaceListener(monitor);

		container.add(new JLabel("Each grid square is equal to 500ms:"));
        container.add(monitor);

        //Align the left edges of the components.
        monitor.setAlignmentX(Component.LEFT_ALIGNMENT);

		container.add(new JLabel("Avl Interval"));
		container.add(avlInterval = new JTextField(4));
		container.add(new JLabel("Heart Interval"));
		container.add(hInterval = new JTextField(4));
		container.add(new JLabel("Heart Refractory Interval"));
		container.add(rInterval = new JTextField(4));
		container.add(new JLabel("Pacing Interval"));
		container.add(pInterval = new JTextField(4));
		container.add(new JLabel("Device Refractory Interval"));
		container.add(drInterval = new JTextField(4));
		container.add(actionButton = new JButton("Change Values"));
		hInterval.setText(myHeart.myVent.getVentInterval() + "");
		rInterval.setText(myHeart.myVent.getVRI() + "");
		pInterval.setText(myDevice.getDeviceInterval() + "");
		avlInterval.setText(myHeart.myAvlNode.getAVLInterval() + "");
		drInterval.setText(myDevice.getDRI() + "");
        actionButton.addActionListener(this);
    }


    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {


        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        Simulator controller = new Simulator();
        controller.buildUI(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
	{
	    if(e.getSource() == actionButton)
	    {
			myHeart.myVent.setVentInterval(Integer.parseInt(hInterval.getText().trim()));
	        myHeart.myVent.setVRI(Integer.parseInt(rInterval.getText().trim()));
	        myDevice.setDeviceInterval(Integer.parseInt(pInterval.getText().trim()));
	        myDevice.setDRI(Integer.parseInt(drInterval.getText().trim()));
	        myHeart.myAvlNode.setAVLInterval(Integer.parseInt(avlInterval.getText().trim()));
	    }
	}

}


