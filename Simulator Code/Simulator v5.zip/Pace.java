/*
 * Pace.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Pace object that will be passed via the PaceEvent object. Creates static Pace
 * objects for easy reference.
 */

/**
 *
 * @author egranse
 */

public class Pace {



    private String pace;

    /** Creates a new instance of Pace */
    public Pace() {
    }

    /** Creates a new instance of Pace taking a string message as a parameter */
    private Pace(String pace) {
        this.pace = pace;
    }

    public static final Pace PACE = new Pace("Pace Sensed");
    public static final Pace R_START = new Pace("Device Refractory started");
    public static final Pace R_END = new Pace("Device Refractory ended");

    /*Returns the message contained within the pace. Used by the listener if a
     *text output is desired.
     */
    public String toString() {
        return pace;
    }



}
