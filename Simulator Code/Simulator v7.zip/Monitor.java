/*
 * HeartMonitor.java
 *
 * Created on June 20, 2005, 11:11 PM
 *
 * 
 */

/**
 *
 * @author egranse
 */
// import heart.*;
import javax.swing.*;
import java.util.*;

import java.awt.*;
import java.util.TimerTask;

public class Monitor extends JComponent{
    private java.util.Timer timer;
    protected int xPosition = 0;
    private ArrayList monitors = new ArrayList();
    
    Color backgroundColor = Color.BLACK;
    Color gridColor = Color.GRAY;
    Color senseColor = Color.YELLOW;	//a chamber pace of any type
    Color chamberRefractoryColor = Color.RED;
    Color sweepColor = Color.WHITE;
    Color escapePaceColor = Color.GREEN;
    Color triggeredPaceColor = Color.WHITE;
    Color maxPaceColor = Color.RED;
    Color refractoryColor = Color.RED;

    int chamberElapsedTime = (int)System.currentTimeMillis();
    int chamberRefractTime;

    public Monitor() {
        timer = new java.util.Timer();
        timer.schedule(new PaintTask(), 0, 25);
    }
    
    public void addTrace(Device d, JPanel p){
    	Trace dm = new Trace();
    	monitors.add(dm);
    	d.addPaceListener(dm);
    	p.add(dm);
    }

    //increments the sweep position and repaints a one-pixel column every time
    //the timer expires.
    class PaintTask extends TimerTask{
    	public void run(){
            xPosition++;
            if(xPosition > 600){
                xPosition = 0;
            }
            Iterator monitorsIterator = monitors.iterator();
            while (monitorsIterator.hasNext()) {
	        	((Trace)monitorsIterator.next()).repaint(xPosition, 0, 2, 100);
	        }
    	}
    }
    
    class Trace extends JComponent implements PaceListener{
        Dimension preferredSize = new Dimension(600,80);
         
        protected boolean paintSense = false;
        protected boolean paintEscapePace = false;
        protected boolean paintTriggeredPace = false;
        protected boolean paintMaxPace = false;
        protected boolean paintRefractory = false;

        int chamberElapsedTime = (int)System.currentTimeMillis();
        int chamberRefractTime;
        int deviceElapsedTime = (int)System.currentTimeMillis();
        int deviceRefractTime;

        public Trace() {
            paintSense = false;
            paintEscapePace = false;
            paintTriggeredPace = false;
            paintMaxPace = false;
            paintRefractory = false;


            setBackground(backgroundColor);
            setOpaque(true);
        }

        public void paceSensed(PaceEvent event) {
    	//	System.out.println(event.pace.toString());
    		if(event.pace == Pace.ESC_PACE){
    			System.out.println("\nDevice escape pace event at " + ((int)System.currentTimeMillis() - deviceElapsedTime));
                deviceElapsedTime = (int)System.currentTimeMillis();
    			paintEscapePace = true;
    		}
    		if(event.pace == Pace.TRIGGERED_PACE){
    			System.out.println("\nDevice triggered pace event at " + ((int)System.currentTimeMillis() - deviceElapsedTime));
                deviceElapsedTime = (int)System.currentTimeMillis();
    			paintTriggeredPace = true;
    		}
    		if(event.pace == Pace.MAX_PACE){
    			System.out.println("\nDevice max rate pace event at " + ((int)System.currentTimeMillis() - deviceElapsedTime));
                deviceElapsedTime = (int)System.currentTimeMillis();
    			paintMaxPace = true;
    		}
    		else if(event.pace == Pace.R_START){
    			deviceRefractTime = (int)System.currentTimeMillis();
    			System.out.println("\nDevice refractory started at " + ((int)System.currentTimeMillis() - deviceRefractTime));
    			paintRefractory = true;
    		}
    		else if(event.pace == Pace.R_END){
    			System.out.println("\nDevice refractory ended at " + ((int)System.currentTimeMillis() - deviceRefractTime));
    			paintRefractory  = false;
    		}
    		else if(event.pace == Pace.SENSE){
    			System.out.println("\nBeat sensed by device");
    			paintSense = true;
    		}
        }

        public Dimension getPreferredSize() {
            return preferredSize;
        }

        protected void paintComponent(Graphics g) {
            int baseline = getHeight() / 2;
            int topline = baseline - getHeight() /4;
            int bottomline = baseline + getHeight() /4;
            if (isOpaque()) {
                g.setColor(getBackground());
                g.fillRect(0, 0, getWidth(), getHeight());
            }

            //Paint 20x20 grid.
            g.setColor(gridColor);
            drawGrid(g, 20);

            if(paintSense){
                g.setColor(senseColor);
                g.drawLine(xPosition, baseline, xPosition, topline);
                paintSense = false;
            }
            if(paintRefractory){
                g.setColor(refractoryColor);
                g.drawLine(xPosition, baseline, xPosition, baseline);
            }
            if(paintEscapePace){
                g.setColor(escapePaceColor);
                g.drawLine(xPosition, baseline, xPosition, bottomline);
                paintEscapePace = false;
            }
            if(paintTriggeredPace){
                g.setColor(triggeredPaceColor);
                g.drawLine(xPosition, baseline, xPosition, bottomline);
                paintTriggeredPace = false;
            }
            if(paintMaxPace){
                g.setColor(maxPaceColor);
                g.drawLine(xPosition, baseline, xPosition, bottomline);
                paintMaxPace = false;
            }
     	g.setColor(sweepColor);
    	g.drawLine(xPosition+1, 0, xPosition+1, getHeight());

        }

        //Draws a 20x20 grid using the current color.
        private void drawGrid(Graphics g, int gridSpace) {
            Insets insets = getInsets();
            int firstX = insets.left;
            int firstY = insets.top;
            int lastX = getWidth() - insets.right;
            int lastY = getHeight() - insets.bottom;

            //Draw vertical lines.
            int x = firstX;
            while (x < lastX) {
                g.drawLine(x, firstY, x, lastY);
                x += gridSpace;
            }
        }
    }
}
