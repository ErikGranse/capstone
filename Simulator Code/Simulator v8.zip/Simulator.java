
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class Simulator implements ActionListener, ItemListener{
	Ventricle myHeart;
	Device myDevice;
    HeartMonitor monitor;
	public JTextField chamberRefractoryInterval, avNodeEscapeInterval;
	public JTextField deviceEscapePace, deviceRefractoryInterval, deviceMaxPaceInterval, deviceMode;
    public JButton ventricleUpdateButton, deviceUpdateButton, runScript;
    private JCheckBox showHeart;
    private JPanel trace;
    private JPanel heartTrace;
    private JPanel ventricleControls;
    private JPanel deviceControls;
    private GridBagConstraints c = new GridBagConstraints();
    JFileChooser chooser;
    private Thread runS;
    private Runnable runSc;
    ProtocolController myP;
	public Simulator()
	{
		myHeart = new Ventricle();
		myDevice = new Device(myHeart);
		chooser = new JFileChooser();
	}

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private void buildUI(Container container) {
    	
        HeartMonitor heartMonitor = new HeartMonitor();
        Monitor monitor = new Monitor();
        
		myHeart.chamber.addBeatListener(heartMonitor);
		myHeart.chamber.addBeatListener(myDevice);
		//myDevice.addPaceListener(dMonitor);
		
		heartTrace = new JPanel();
		heartTrace.setLayout(new BoxLayout(heartTrace, BoxLayout.PAGE_AXIS));
		heartTrace.add(heartMonitor);
		
		//trace holds the elements associated with displaying the output of the
		//simulation.
		trace = new JPanel();
		trace.setLayout(new BoxLayout(trace, BoxLayout.PAGE_AXIS));
		trace.add(new JLabel("Each grid square is approximately equal to 500ms:"));
		monitor.addTrace(myDevice, trace);
	//	monitor.addTrace(myDevice, trace);
		
	    //ventricleControls contains the labels and fields necessary to control the
	    //heart object.
		ventricleControls = new JPanel();
		ventricleControls.setLayout(new BoxLayout(ventricleControls, BoxLayout.PAGE_AXIS));
		ventricleControls.setBorder(BorderFactory.createTitledBorder("Ventricle Controls"));
		ventricleControls.add(new JLabel("AV Node Escape Interval:"));
		ventricleControls.add(avNodeEscapeInterval = new JTextField(4));
		ventricleControls.add(new JLabel("Chamber Refractory Interval:"));
		ventricleControls.add(chamberRefractoryInterval = new JTextField(4));
		ventricleControls.add(ventricleUpdateButton = new JButton("Apply"), c);
		
	    //deviceControls contains the labels and fields necessary to control the
	    //device object.
		deviceControls = new JPanel();
		deviceControls.setLayout(new BoxLayout(deviceControls, BoxLayout.PAGE_AXIS));
    	deviceControls.setBorder(BorderFactory.createTitledBorder("Device Controls"));
		deviceControls.add(new JLabel("Escape Pace Interval:"));
		deviceControls.add(deviceEscapePace = new JTextField(4));
		deviceControls.add(new JLabel("Max Pace Interval:"));
		deviceControls.add(deviceMaxPaceInterval = new JTextField(4));
		deviceControls.add(new JLabel("Refractory Interval:"));
		deviceControls.add(deviceRefractoryInterval = new JTextField(4));
		deviceControls.add(new JLabel("Mode:"));
		deviceControls.add(deviceMode = new JTextField(4));
		deviceControls.add(deviceUpdateButton = new JButton("Apply"), c);
		deviceControls.add(runScript = new JButton("Run Script"), c);		

        //Align the left edges of the components.
        heartMonitor.setAlignmentX(Component.LEFT_ALIGNMENT);
        
    	//container is the content pane; it holds all other elements.
        //Grid layout:
        //
        // ----------------------------------------------------------
        // |TRACE                                                   |
        // |--------------------------------------------------------|
        // |HEARTCONTROLS   |  DEVICE CONTROLS                      |
        // |--------------------------------------------------------|
        // |CHANGE BUTTON                                           |
        // ----------------------------------------------------------
        
    	container.setLayout(new GridBagLayout());

		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		container.add(heartTrace, c);
		
		c.gridx = 0;
		c.gridy = 1;
		container.add(trace, c);
		
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		container.add(ventricleControls, c);
		
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		container.add(deviceControls, c);
		
		c.gridx = 0;
		c.gridy = 3;
		container.add(showHeart = new JCheckBox("Show heart trace"), c);
		showHeart.setSelected(true);
		
		chamberRefractoryInterval.setText(myHeart.chamber.getChamberRefractoryInterval() + "");
		deviceEscapePace.setText(myDevice.getDeviceEscapeInterval() + "");
		avNodeEscapeInterval.setText(myHeart.avNode.getAVEscapeInterval() + "");
		deviceRefractoryInterval.setText(myDevice.getDeviceRefractoryInterval() + "");
		deviceMaxPaceInterval.setText(myDevice.getDeviceMaxPaceInterval() + "");
		deviceMode.setText(myDevice.getMode());
		
		ventricleUpdateButton.addActionListener(this);
		runScript.addActionListener(this);
		deviceUpdateButton.addActionListener(this);
		showHeart.addItemListener(this);
        
    }


    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {


        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        Simulator controller = new Simulator();
        controller.buildUI(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
	{
	    if(e.getSource() == ventricleUpdateButton)
	    {
	        myHeart.chamber.setChamberRefractoryInterval(Integer.parseInt(chamberRefractoryInterval.getText().trim()));
	        myHeart.avNode.setAVEscapeInterval(Integer.parseInt(avNodeEscapeInterval.getText().trim()));
	    }
	    else if(e.getSource() == deviceUpdateButton)
	    {
	        myDevice.setDeviceEscapeInterval(Integer.parseInt(deviceEscapePace.getText().trim()));
	        myDevice.setDeviceRefractoryInterval(Integer.parseInt(deviceRefractoryInterval.getText().trim()));
	        myDevice.setDeviceMaxPaceInterval(Integer.parseInt(deviceMaxPaceInterval.getText().trim()));
	        myDevice.setMode(deviceMode.getText().trim());
	    }
	    else if(e.getSource() == runScript)
	    {
	    	try{
	   		File curDir = new File(new File(".").getCanonicalPath());
	   		chooser.setCurrentDirectory(curDir);
    int returnVal = chooser.showOpenDialog(null);
    if(returnVal == JFileChooser.APPROVE_OPTION) {
       System.out.println("You chose to open this file: ");
       String myFile = (String)(chooser.getSelectedFile().getName());
        myP = new ProtocolController(myFile, myDevice);
    	try{
    			runSc = new Runnable(){
			public void run(){
				runA();
			}
		};
		runS = new Thread(runSc, "Run ");
		runS.start();
    		}catch(Exception me){}
    				
    		}} catch(Exception p){}

	    
	    
	    }
	    }
	    
    public void itemStateChanged(ItemEvent e){
    	
        if (e.getItemSelectable() == showHeart) {
        	if (e.getStateChange() == ItemEvent.DESELECTED){
        		heartTrace.setVisible(false);
        	}
        	else{
        		heartTrace.setVisible(true);
        	}
        }
    }
    public void runA()
    {
    	try{
    		myP.runScript();
    	}catch(Exception why){}
    }

}


