/**
 * AWT Sample application
 *
 * @author 
 * @version 1.00 05/07/18
 */
 
import java.io.*;
 
public class ProtocolController {
	String  myFile = "";
	Device myDevice;
	public ProtocolController(String aFile, Device aDevice)
	{
		myFile = aFile;
		myDevice = aDevice;
	}

    
    public void runScript() throws Exception {
    	

			BufferedReader readScript = null;			
			
            
	        try {
	            readScript = new BufferedReader(new FileReader(myFile));

	        }
	        catch (FileNotFoundException e) {
	            System.err.println("File not found or Could not open file!");
	        }
	        
	        L lexer = new L(readScript);
	        P parser = new P(lexer);
	        while(readScript.ready())
	        {
	        
            parser.startRule(readScript, this);
   }
            
    }

    public void setDeviceRate(int rate) {
   
    	float temp = (float)(60.0 / rate);
    	int interval = (int)(temp * 1000);
    	myDevice.setDeviceEscapeInterval(interval);
    }
    
    public void setRefractory(int interval) {
   
        	myDevice.setDeviceRefractoryInterval(interval);
    }
  }  
