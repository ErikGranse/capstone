/* The AVNode is responsible for pacing a chamber as part of an overall
 * ventricle. It will provide its own pacing(escape) rate; in a multi-
 * chamber model, it will listen to an atrium chamber for paces, and
 * then initiate the AV Delay before pacing its own chamber.
 * 
 */

public class AVNode{
	private Chamber myChamber;
	
	public Thread avEscapeThread;
	public Thread avDelayThread;
	
	private Runnable runAVEscapeThread;
	private Runnable runAVDelayThread;
	
	private volatile int avEscapeInterval = 2000;
	private volatile int avDelayInterval = 100;
	

	public AVNode(Chamber chamber)
	{
		myChamber = chamber;
		runAVEscapeThread = new Runnable()
		{
			public void run()
			{
				runAVEscapeInterval();
			}
		};
		
		runAVDelayThread = new Runnable()
		{
			public void run()
			{
				runAVDelayInterval();
			}
		};

		//Initializes and runs the escape interval thread
		avEscapeThread = new Thread(runAVEscapeThread, "avEscapeThread");
		avEscapeThread.start();
	}
	
	public void runAVEscapeInterval(){
		while(true){
			try{
				while(true){
					avEscapeThread.sleep(avEscapeInterval);
					if(!myChamber.inRefract())
						break;
				}

			}
			catch(Exception e){ }
			if(!myChamber.inRefract()){
				beat();
			}
		}
	}
	
	public void runAVDelayInterval()
	{
		while(true){
			try{
				while(true){
					avDelayThread.sleep(avDelayInterval);
					if(!myChamber.inRefract())
						break;
				}
			}
			catch(Exception e){ }
			if(!myChamber.inRefract()){
				beat();
			}
		}
	}
	
	public void BeatSensed(BeatEvent e){
		if(e.beat == Beat.BEAT){
			runAVDelayInterval();
		}
	}
	
	public void beat(){
		/* This is a redundant check to ensure refractory isn't entered
		/* in the cap between the end of the escape interval and the 
		/* beat() call. */
		if(!myChamber.inRefract()){
			myChamber.setRefractory();
			myChamber.beat();
		}
	}
	
	public synchronized void setAVEscapeInterval(int newTime){
		avEscapeInterval = newTime;
	}
	
	public synchronized int getAVEscapeInterval(){
		return avEscapeInterval;
	}
	
	public synchronized void setAVDelayInterval(int newTime){
		avDelayInterval = newTime;
	}
	
	public synchronized int getAVDelayInterval(){
		return avDelayInterval;
	}
}