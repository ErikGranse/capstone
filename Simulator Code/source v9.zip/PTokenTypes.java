// $ANTLR 2.7.5 (20050128): "device2.g" -> "P.java"$

public interface PTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int RATE = 4;
	int REF = 5;
	int WAIT = 6;
	int MODE = 7;
	int AVD = 8;
	int INT = 9;
	int MODETYPE = 10;
	int WS = 11;
}
