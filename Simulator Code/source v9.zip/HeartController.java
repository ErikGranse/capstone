import java.util.*;

public class HeartController{
	protected SANode mySANode;
	protected Ventricle myVent;
	public HeartController()
	{
		myVent = new Ventricle(this);

		mySANode = new SANode(myVent);
	}
	public boolean inRefract()
	{
		return myVent.inRefract();
	}
	public void beat()
	{
		if(!inRefract())
		{
			myVent.setRefractory();
			mySANode.AvlThread.interrupt();
			myVent.beat();
		}

	}
}