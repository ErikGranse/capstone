import java.util.*;

public class Device{
	private boolean deviceInRefractory = false;
	private volatile int deviceInterval = 200;
	private volatile int deviceRefractoryInterval = 100;
	private int startTime;
	private HeartController myHeart;
	Thread deviceThread, deviceRefractoryThread;
	Runnable runDevice, runDeviceRefractory;
	private Thread myThread;
	private Runnable myRun;

	public Device(HeartController aHeart)
	{
		myHeart = aHeart;
		runDevice = new Runnable()
		{
			public void run()
			{
				devicePace();
			}
		};

		// Defines thread D and associates it with runA
		// then starts up thread D
		deviceThread = new Thread(runDevice, "deviceThread");
		deviceThread.start();
	}

	public void devicePace()
	{
		int time3 = 0;
		while(true)
		{
			try
			{
				while(true)
				{
					time3 = (int)System.currentTimeMillis();
					System.out.println("Device before sleep 0");
					deviceThread.sleep(deviceInterval);
					if(!deviceInRefractory)
							break;
				}

			}
					catch(Exception e){ }
			if(!deviceInRefractory)
			{
				int time2 = (int)(System.currentTimeMillis() - time3);
				System.out.println("Device after sleep " + time2 + "\n");
				deviceBeat();
			}
		}
	}
	public void deviceBeat()
	{
		//System.out.println("Device beating");
		myRun = new Runnable()
		{
			public void run()
			{
				beatTheHeart();
			}
		};

		// Defines thread D and associates it with runA
		// then starts up thread D
		myThread = new Thread(myRun, "deviceThread");
		myThread.start();

		deviceInRefractory = true;
		deviceRefractory();
	}
	public void deviceRefractory()
	{
		runDeviceRefractory = new Runnable()
		{
			public void run()
			{
				startDeviceRefractory();
			}
		};

		// Defines thread D and associates it with runA
		// then starts up thread D
		deviceRefractoryThread = new Thread(runDeviceRefractory, "threaddeviceRefractoryThread");
		deviceRefractoryThread.start();
	}
	public void startDeviceRefractory()
	{
		try
		{
			System.out.println("Device in Refractory");
			deviceRefractoryThread.sleep(deviceRefractoryInterval);
			deviceInRefractory = false;
			System.out.println("Device out of Refractory");
		}
			catch(Exception e){ }
	}
	public void beatTheHeart()
	{
		myHeart.beat();
	}
	public synchronized void setDeviceInterval(int newTime)
	{
		deviceInterval = newTime;
	}
	public synchronized int getDeviceInterval()
	{
		return deviceInterval;
	}
	public synchronized void setDRI(int newTime)
	{
		deviceRefractoryInterval = newTime;
	}
	public synchronized int getDRI()
	{
		return deviceRefractoryInterval;
	}

}