import java.util.*;

public class Heart{
	private AvlNode myAvlNode;
	private Ventricle myVent;
	public Heart()
	{
		myVent = new Ventricle();
		myAvlNode = new AvlNode(myVent);
	}
	public boolean inRefract()
	{
		return myVent.inRefract();
	}
	public void beat()
	{
		if(!inRefract())
		{
			myVent.setRefractory();
			myAvlNode.AvlThread.interrupt();
			myVent.beat();
		}

	}
}