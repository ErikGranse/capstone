/*
 * Vent.java
 *
 * Created on June 20, 2005, 9:46 PM
 *
 * The ventricle acts on no other objects other than via a event publishing.
 * It contains both a beat timer as well as a refractory period timer; each is 
 * simulated by sleeping their respective thread.
 *
 */

/**
 *
 * @author egranse
 */

import java.util.*;

public class Ventricle {
    private Beat beat;
    private List listeners = new ArrayList();
    public int interval = 1500;
    public int refInterval = 600;
    public volatile boolean var = false;
    int initialSystemTime;
    int startSleepTime;
    Thread A, B;

    public Ventricle() {
        Runnable runA = new Runnable() {
            public void run() {
                runWork();
            }
        };
        A = new Thread(runA, "Ventricle_Thread");
        A.start();
    }

    public void runWork() {
        int endSleepTime;
        initialSystemTime = (int) System.currentTimeMillis();
        while ( true ) {
            try {
                while ( true ) {
                    startSleepTime = (int) System.currentTimeMillis() 
                                        - initialSystemTime;
                    beat = Beat.BEAT;
                    fireBeatEvent();
                    Thread.sleep(interval);
                    if ( !var ) break;
                }
            } catch ( Exception e ) {
            }
            if ( !var ) {
                endSleepTime = (int) (System.currentTimeMillis() 
                                    - initialSystemTime);
                var = true;
                Runnable runB = new Runnable() {
                    public void run() {
                        runWork2();
                    }
                };
                Thread B = new Thread(runB, "Refractory_Thread");
                B.start();
            }
        }
    }

    public void runWork2() {
        try {
            int refTime = (int) (System.currentTimeMillis() - initialSystemTime);
            beat = Beat.R_START;
            fireBeatEvent();
            Thread.sleep(refInterval);
            refTime = (int) (System.currentTimeMillis() - initialSystemTime);
            beat = Beat.R_END;
            fireBeatEvent();
            var = false;
        } catch ( Exception e ) {
        }
    }

    //Adds a listener to the listener list.
    public synchronized void addBeatListener(BeatListener bl) {
        listeners.add(bl);
    }

    //Removes a listener from the listener list.
    public synchronized void removeBeatListener(BeatListener bl) {
        listeners.remove(bl);
    }

    //Loops through all listeners and pushes the beatEvent to them.
    private synchronized void fireBeatEvent() {
        BeatEvent beatEvent = new BeatEvent(this, beat);
        Iterator listenerIterator = listeners.iterator();
        while ( listenerIterator.hasNext() ) {
            ((BeatListener) listenerIterator.next()).beatSensed(beatEvent);
        }
    }
}
