/*
 * Beat.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Beat object that will be passed via the BeatEvent object. Creates static Beat
 * objects for easy reference.
 */

/**
 *
 * @author egranse
 */

public class Beat {

    
    
    private String beat;
    
    /** Creates a new instance of Beat */
    public Beat() {
    }
    
    /** Creates a new instance of Beat taking a string message as a parameter */
    private Beat(String beat) {
        this.beat = beat;
    }
    
    public static final Beat BEAT = new Beat("Beat Sensed");        
    public static final Beat R_START = new Beat("Refractory started");
    public static final Beat R_END = new Beat("Refractory ended");

    /*Returns the message contained within the beat. Used by the listener if a
     *text output is desired.
     */
    public String toString() {
        return beat;
    }



}