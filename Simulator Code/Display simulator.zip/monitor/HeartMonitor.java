/*
 * HeartMonitor.java
 *
 * Created on June 20, 2005, 11:11 PM
 *
 * Subscribes to the heart model; sets switches depending on events received.
 * Runs a continous timer; the timer paints a pixel at a time, showing events
 * as set in the switches and then resetting the switch.
 */

/**
 *
 * @author egranse
 */
import heart.*;
import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;

public class HeartMonitor extends JComponent implements BeatListener{
    private java.util.Timer timer;
    protected int xPosition = 0;
    Dimension preferredSize = new Dimension(400,75);
    Color backgroundColor = Color.BLACK;
    Color gridColor = Color.GRAY;
    Color senseColor = Color.YELLOW;
    Color refractoryColor = Color.RED;
    Color sweepColor = Color.WHITE;
    protected boolean paintSense;
    protected boolean paintRefractory;
    
    public HeartMonitor() {
        paintSense = false;
        timer = new java.util.Timer();
        timer.schedule(new PaintTask(), 0, 25);

        setBackground(backgroundColor);
        setOpaque(true);
    }
    
    public void beatSensed(BeatEvent event) {
        System.out.println(event.beat.toString());
        if(event.beat == Beat.BEAT){
            paintSense = true;
        }
        else if(event.beat == Beat.R_START){
            paintRefractory = true;
        }
        else if(event.beat == Beat.R_END){
            paintRefractory = false;
        }
    }

    public Dimension getPreferredSize() {
        return preferredSize;
    }
    
    protected void paintComponent(Graphics g) {
        int baseline = getHeight() / 2;
        if (isOpaque()) {
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        //Paint 20x20 grid.
        g.setColor(gridColor);
        drawGrid(g, 20);
        
        if(paintSense){
            g.setColor(senseColor);
            g.drawLine(xPosition, baseline, xPosition, 10);
            paintSense = false;
        }
        if(paintRefractory){
            g.setColor(refractoryColor);
            g.drawLine(xPosition, baseline, xPosition, baseline);
            paintSense = false;
        }
	g.setColor(sweepColor);
	g.drawLine(xPosition+1, 0, xPosition+1, getHeight());

    }

    //Draws a 20x20 grid using the current color.
    private void drawGrid(Graphics g, int gridSpace) {
        Insets insets = getInsets();
        int firstX = insets.left;
        int firstY = insets.top;
        int lastX = getWidth() - insets.right;
        int lastY = getHeight() - insets.bottom;

        //Draw vertical lines.
        int x = firstX;
        while (x < lastX) {
            g.drawLine(x, firstY, x, lastY);
            x += gridSpace;
        }

        //Draw horizontal lines.
        int y = firstY;
        while (y < lastY) {
            g.drawLine(firstX, y, lastX, y);
            y += gridSpace;
        }
    }
    
    //increments the sweep position and repaints a one-pixel column every time
    //the timer expires.
    class PaintTask extends TimerTask{
	public void run(){
            xPosition++;
            if(xPosition > getWidth()){
                xPosition = 0;
            }
            repaint(xPosition, 0, 2, getHeight());
	}
    }
}
