// LOCALIZATION STRING

// Strings for calendar.js and calendar_param.js
var L_Today     ="[A]Today[g]";
var L_January   ="[A]January[g]";
var L_February  ="[A]February[g]";
var L_March     ="[A]March[g]";
var L_April     ="[A]April[g]";
var L_May       ="[A]May[g]";
var L_June      ="[A]June[g]";
var L_July      ="[A]July[g]";
var L_August    ="[A]August[g]";
var L_September ="[A]September[g]";
var L_October   ="[A]October[g]";
var L_November  ="[A]November[g]";
var L_December  ="[A]December[g]";
var L_Su        ="[A]Su[g]";
var L_Mo        ="[A]Mo[g]";
var L_Tu        ="[A]Tu[g]";
var L_We        ="[A]We[g]";
var L_Th        ="[A]Th[g]";
var L_Fr        ="[A]Fr[g]";
var L_Sa        ="[A]Sa[g]";

// strings for dt_param.js
var TIME_SEPARATOR = ":";
var AM_DESIGNATOR = "AM";
var PM_DESIGNATOR = "PM";

// strings for range parameter
var FROM = "From {0}";
var TO = "To {0}";
var AFTER = "After {0}";
var BEFORE = "Before {0}";
var FROM_TO = "From {0} to {1}";
var FROM_BEFORE = "From {0} to before {1}";
var AFTER_TO = "After {0} to {1}";
var AFTER_BEFORE = "After {0} to before {1}";

// Strings for prompts.js and prompts_param.js
var L_BadNumber		="[A]This parameter is of type \"Number\" and can only contain a negative sign, digits (\"0-9\"), and a period decimal separator. Please correct the entered parameter value.[g]";
var L_BadCurrency	="[A]This parameter is of type \"Currency\" and can only contain a negative sign, digits (\"0-9\"), and a period decimal separator. Please correct the entered parameter value.[g]";
var L_BadDate		="[A]This parameter is of type \"Date\" and should be in the format \"Date(yyyy,mm,dd)\" where \"yyyy\" is the four digit year, \"mm\" is the month (e.g. January = 1), and \"dd\" is the number of days into the given month.[g]";
var L_BadDateTime   ="[A]This parameter is of type \"DateTime\" and the correct format is \"DateTime(yyyy,mm,dd,hh,mm,ss)\". \"yyyy\" is the four digit year, \"mm\" is the month (e.g. January = 1), \"dd\" is the day of the month, \"hh\" is hours in a 24 hour, \"mm\" is minutes and \"ss\" is seconds.[g]";
var L_BadTime       ="[A]This parameter is of type \"Time\" and should be in the format \"Time(hh,mm,ss)\" where \"hh\" is hours in 24 a hour clock, \"mm\" is minutes into the hour, and \"ss\" is seconds into the minute.[g]";
var L_NoValue       ="[A]No Value[g]";
var L_BadValue      ="[A]To set \"No Value\", you must set both From and To values to \"No Value\".[g]";
var L_BadBound      ="[A]You cannot set \"No Lower Bound\" together with \"No Upper Bound\".[g]";
var L_NoValueAlready ="[A]This parameter is already set to \"No Value\". Remove \"No Value\" before adding other values[g]";

// Strings for ../html/crystalexportdialog.htm
var L_ExportOptions     ="[A]Export Options[g]";
var L_PrintOptions      ="[A]Print Options[g]";
var L_PrintPageTitle    ="[A]Print the Report[g]";
var L_ExportPageTitle   ="[A]Export the Report[g]";
var L_OK                ="[A]OK[g]";
var L_PrintPageRange    ="[A]Enter the page range that you want to Print.[g]";
var L_ExportPageRange   ="[A]Enter the page range that you want to Export.[g]";
var L_InvalidPageRange  ="[A]The page range value(s) are incorrect.  Please enter a valid page range.[g]";
var L_ExportFormat      ="[A]Please select an Export format from the list.[g]";
var L_Formats           ="[A]Formats:[g]";
var L_All               ="[A]All[g]";
var L_Pages             ="[A]Pages[g]";
var L_From              ="[A]From:[g]";
var L_To                ="[A]To:[g]";
var L_PrintStep0        ="[A]To Print:[g]";
var L_PrintStep1        ="[A]1.  In the next dialog that appears, select the \"Open this file\" option and click the OK button.[g]";
var L_PrintStep2        ="[A]2.  Click the printer icon on the Acrobat Reader Menu rather than the print button on your internet browser.[g]";
var L_RTFFormat         ="[A]Rich Text Format[g]";
var L_AcrobatFormat     ="[A]Acrobat Format (PDF)[g]";
var L_CrystalRptFormat  ="[A]Crystal Reports (RPT)[g]";
var L_WordFormat        ="[A]MS Word[g]";
var L_ExcelFormat       ="[A]MS Excel 97-2000[g]";
var L_ExcelRecordFormat ="[A]MS Excel 97-2000 (Data Only)[g]";
