import java.util.*;

public class Ventricle{
	private Beat beat;
    private List listeners = new ArrayList();
	private Thread VentThread;
	private Runnable runVentThread;
	private Thread VentRefractoryThread;
	private Runnable runVentRefractoryThread;
	private int time3;
	private volatile int ventInterval = 2000;
	private volatile int ventRefractoryInterval = 200;
	private volatile boolean inRefractory = false;
	private HeartController myH;

	public Ventricle(HeartController h)
	{
		// Defines runVentThread and states that when it is run
		// it calls runWork
		myH = h;
		runVentThread = new Runnable()
		{
			public void run()
			{
				startVentInterval();
			}
		};

		// Defines thread VentThread and associates it with runVentThread
		// then starts up thread VentThread
		VentThread = new Thread(runVentThread, "threadA");
		VentThread.start();
	}
	public void startVentInterval(){
		while(true)
		{
			time3 = (int)System.currentTimeMillis();
			try
			{
				while(true)
				{
			//		System.out.println("ventricle before sleep 0");
					VentThread.sleep(ventInterval);
					if(!inRefractory)
						break;
				}

			}
			catch(Exception e){ }
			if(!inRefractory)
			{
				int time2 = (int)(time3 - System.currentTimeMillis() );
	//			System.out.println("ventricle after sleep " + time2 + "\n");
				inRefractory = true;
				beat();
	//			myH.myAvlNode.AvlThread.interrupt();


			}
		}
	}
	public synchronized void beat(){
//		System.out.println("Vent beating!");
		beat = Beat.BEAT;

		fireBeatEvent();

		refractoryPeriod();
	}
	public synchronized void refractoryPeriod()
	{
		VentThread.interrupt();
		runVentRefractoryThread = new Runnable()
		{
			public void run()
			{
				startVentRefractory();
			}
		};

		// Defines thread VentThread and associates it with runVentThread
		// then starts up thread A
		VentRefractoryThread = new Thread(runVentRefractoryThread, "threadC");
		VentRefractoryThread.start();
	}
	public void startVentRefractory()
	{
	//	System.out.println("Ventricle in refractory");
		try
		{
			beat = Beat.R_START;
            fireBeatEvent();
			VentRefractoryThread.sleep(ventRefractoryInterval);
			beat = Beat.R_END;
            fireBeatEvent();
			inRefractory = false;
		}
		catch(Exception e){ }
	//	System.out.println("Ventricle out of refractory");

	}
	public synchronized boolean inRefract()
	{
		return inRefractory;
	}
	public void setRefractory()
	{
		inRefractory = true;
	}
	   //Adds a listener to the listener list.
	    public synchronized void addBeatListener(BeatListener bl) {
	        listeners.add(bl);
	    }

	    //Removes a listener from the listener list.
	    public synchronized void removeBeatListener(BeatListener bl) {
	        listeners.remove(bl);
	    }

	    //Loops through all listeners and pushes the beatEvent to them.
	    private synchronized void fireBeatEvent() {
	        BeatEvent beatEvent = new BeatEvent(this, beat);
	        Iterator listenerIterator = listeners.iterator();
	        while ( listenerIterator.hasNext() ) {
	            ((BeatListener) listenerIterator.next()).beatSensed(beatEvent);
	        }
    }
    public synchronized void setVentInterval(int newTime)
	{
		ventInterval = newTime;
	}
	public synchronized int getVentInterval()
	{
		return ventInterval;
	}
	public synchronized void setVRI(int newTime)
	{
		ventRefractoryInterval = newTime;
	}
	public synchronized int getVRI()
	{
		return ventRefractoryInterval;
	}

}