import java.util.*;

public class SANode{
	private Ventricle myVent;
	public Thread AvlThread;
	private Runnable runAvl;
	private int time3;
	private volatile int avlInterval = 1000;

	public SANode(Ventricle aVent)
	{
		myVent = aVent;
		runAvl = new Runnable()
		{
			public void run()
			{
				runAvlInterval();
			}
		};

		// Defines thread A and associates it with runA
		// then starts up thread A
		AvlThread = new Thread(runAvl, "AvlThread");
		AvlThread.start();
	}
	public void runAvlInterval()
	{
		while(true)
		{
			int timeLeft = avlInterval;
			try
			{
				time3 = (int)System.currentTimeMillis();
				while(true)
				{
		//			System.out.println("AvlNode before sleep " + (avlInterval - timeLeft));
					AvlThread.sleep(avlInterval);
					timeLeft = timeLeft + (time3 - (int)(System.currentTimeMillis()));
					if(!myVent.inRefract())
						break;
				}

			}
			catch(Exception e){ }
			if(!myVent.inRefract())
			{
				int time2 = (int)(System.currentTimeMillis() - time3);
		//		System.out.println("AvlNode after sleep " + time2 + "\n");
				beat();

			}
		}
	}
	public void beat(){
		//	System.out.println("AvlNode sent pulse");
			if(!myVent.inRefract())
			{
				myVent.setRefractory();
				myVent.beat();
			}
	}
	public synchronized void setAVLInterval(int newTime)
	{
		avlInterval = newTime;
	}
	public synchronized int getAVLInterval()
	{
		return avlInterval;
	}

}