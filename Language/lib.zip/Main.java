import antlr.*;
import java.io.*;

public class Main {
	private static Device myDevice;
	
	public Main(Device d)
	{
		myDevice = d;
	}
        public static void main (String[] args) throws Exception {
                L lexer = new L(new DataInputStream(System.in));
                P parser = new P(lexer);
                parser.startRule(myDevice);
               // System.out.println("value returned is " + k);
                //System.out.println(x);
        }
}