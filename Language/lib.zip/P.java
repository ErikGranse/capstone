// $ANTLR 2.7.5 (20050128): "device.g" -> "P.java"$

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;

public class P extends antlr.LLkParser       implements PTokenTypes
 {

protected P(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public P(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected P(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public P(TokenStream lexer) {
  this(lexer,1);
}

public P(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void startRule(
		Device myDevice
	) throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			cmnd(myDevice);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void cmnd(
		Device g
	) throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case RATE:
			{
				rateRule();
				break;
			}
			case MODE:
			{
				modeRule();
				break;
			}
			case AVD:
			{
				avdRule();
				break;
			}
			case NUM:
			{
				numRule(g);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void rateRule() throws RecognitionException, TokenStreamException {
		
		Token  r = null;
		
		try {      // for error handling
			r = LT(1);
			match(RATE);
			System.out.println("Pace " + r.getText());
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void modeRule() throws RecognitionException, TokenStreamException {
		
		Token  m = null;
		
		try {      // for error handling
			m = LT(1);
			match(MODE);
			System.out.println("Pace " + m.getText());
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void avdRule() throws RecognitionException, TokenStreamException {
		
		Token  a = null;
		
		try {      // for error handling
			a = LT(1);
			match(AVD);
			System.out.println("Pace " + a.getText());
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void numRule(
		Device e
	) throws RecognitionException, TokenStreamException {
		
		Token  n = null;
		
		try {      // for error handling
			n = LT(1);
			match(NUM);
			
						String temp = n.getText();
						int k = Integer.parseInt(temp.substring(4));
						System.out.println("num = " + k);
						e.setDeviceInterval(k);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"RATE",
		"MODE",
		"AVD",
		"NUM",
		"INT",
		"MODETYPE",
		"WS"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	
	}
