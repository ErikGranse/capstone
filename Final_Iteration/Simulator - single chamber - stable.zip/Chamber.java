/**
 * A chamber is a generic heart chamber; it is used interchangably with
 * either an SANode or AVNode to create an atrium or ventricle 
 * respectively.
 * 
 * A chamber contains its own escape rate, which under normal rhythm 
 * would never pace. It exists as a last-stop pace maker.
 * 
 * The chamber also contains a refractory interval, which is triggered
 * on any beat event and will suppress any further attempt at beating
 * while in effect.
 * 
 * Contains methods for adding, removing and notifying listeners; that is 
 * the main purpose of this class.
 */

import java.util.*;

public class Chamber{
	private Beat beat;
    private List listeners = new ArrayList();
	private Thread chamberRefractoryThread;
	private Runnable runChamberRefractoryThread;
	private volatile int chamberRefractoryInterval = 200;
	private volatile boolean inRefractory = false;

	public Chamber(){
	}

	public synchronized void beat(){
		beat = Beat.BEAT;
		fireBeatEvent();
		refractoryPeriod();
	}

	public synchronized void refractoryPeriod()
	{
		runChamberRefractoryThread = new Runnable()
		{
			public void run()
			{
				startChamberRefractory();
			}
		};

		// Defines thread chamberRefractoryThread and associates it with runChamberEscapeThread
		// then starts up chamberRefractoryThread
		chamberRefractoryThread = new Thread(runChamberRefractoryThread, "threadC");
		chamberRefractoryThread.start();
	}
	
	
	//called upon beating. 
	public void startChamberRefractory(){
		try{
			beat = Beat.R_START;
            fireBeatEvent();
			chamberRefractoryThread.sleep(chamberRefractoryInterval);
			beat = Beat.R_END;
            fireBeatEvent();
			inRefractory = false;
		}
		catch(Exception e){ }
	}

	public synchronized boolean inRefract()	{
		return inRefractory;
	}
	public void setRefractory()	{
		inRefractory = true;
	}
	
	//Adds a listener to the listener list.
	public synchronized void addBeatListener(BeatListener bl) {
	    listeners.add(bl);
	}

	//Removes a listener from the listener list.
	public synchronized void removeBeatListener(BeatListener bl) {
	    listeners.remove(bl);
	}

	//Loops through all listeners and pushes the beatEvent to them.
	private synchronized void fireBeatEvent() {
	    BeatEvent beatEvent = new BeatEvent(this, beat);
	    Iterator listenerIterator = listeners.iterator();
	    while ( listenerIterator.hasNext() ) {
	        ((BeatListener) listenerIterator.next()).beatSensed(beatEvent);
	    }
    }
    
	public synchronized void setChamberRefractoryInterval(int newTime){
		chamberRefractoryInterval = newTime;
	}
	
	public synchronized int getChamberRefractoryInterval(){
		return chamberRefractoryInterval;
	}
}