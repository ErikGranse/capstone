// $ANTLR 2.7.5 (20050128): "Language.g" -> "P.java"$

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;

import java.io.*;
import java.util.*;

public class P extends antlr.LLkParser       implements PTokenTypes
 {

protected P(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public P(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected P(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public P(TokenStream lexer) {
  this(lexer,1);
}

public P(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void startRule(
		BufferedReader myReader, ProtocolController myController
	) throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			cmnd(myReader, myController);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void cmnd(
		BufferedReader g, ProtocolController h
	) throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case RATE:
			{
				rateRule(h);
				break;
			}
			case REF:
			{
				refractoryRule(h);
				break;
			}
			case WAIT:
			{
				waitRule();
				break;
			}
			case MODE:
			{
				modeRule(h);
				break;
			}
			case AVD:
			{
				avdRule(h);
				break;
			}
			case COUNT:
			{
				countRule(h);
				break;
			}
			case PRINTCOMMENT:
			{
				commentRule();
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void rateRule(
		ProtocolController z 
	) throws RecognitionException, TokenStreamException {
		
		Token  r = null;
		
		try {      // for error handling
			r = LT(1);
			match(RATE);
			
				        
						String myString = r.getText();
						int k = Integer.parseInt(myString.substring(5));
						System.out.println("Rate = " + k);
						z.setDeviceRate(k);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void refractoryRule(
		ProtocolController b 
	) throws RecognitionException, TokenStreamException {
		
		Token  f = null;
		
		try {      // for error handling
			f = LT(1);
			match(REF);
			
				        
						String ref = f.getText();
						int k = Integer.parseInt(ref.substring(4));
						System.out.println("Refractory = " + k);
						b.setRefractory(k);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void waitRule() throws RecognitionException, TokenStreamException {
		
		Token  w = null;
		
		try {      // for error handling
			w = LT(1);
			match(WAIT);
			
				        
						String wait = w.getText();
						int k = Integer.parseInt(wait.substring(5));
						System.out.println("Wait = " + k);
						try {
						Thread.sleep(k);
						}catch(Exception e){
						}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void modeRule(
		ProtocolController pc 
	) throws RecognitionException, TokenStreamException {
		
		Token  m = null;
		
		try {      // for error handling
			m = LT(1);
			match(MODE);
			
						String temp = m.getText();
						String temp2 = temp.substring(5);
						System.out.println("Mode is " + temp2);
						pc.changeMode(temp2);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void avdRule(
		ProtocolController pc 
	) throws RecognitionException, TokenStreamException {
		
		Token  a = null;
		
		try {      // for error handling
			a = LT(1);
			match(AVD);
			
						String temp = a.getText();
						int k = Integer.parseInt(temp.substring(4));
						System.out.println("AVD is " + k);
						pc.setAVDelay(k);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void countRule(
		ProtocolController pc 
	) throws RecognitionException, TokenStreamException {
		
		Token  c = null;
		
		try {      // for error handling
			c = LT(1);
			match(COUNT);
			
						String line = c.getText();
						String event = line.substring(6);
						int value = Integer.parseInt(line.substring(9));
						System.out.println("Event is " + event);
						System.out.println("Count is " + value);
						pc.setCount(event, value);
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	public final void commentRule() throws RecognitionException, TokenStreamException {
		
		Token  p = null;
		
		try {      // for error handling
			p = LT(1);
			match(PRINTCOMMENT);
			
							System.out.println(p.getText());
						
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"RATE",
		"REF",
		"WAIT",
		"MODE",
		"AVD",
		"COUNT",
		"PRINTCOMMENT",
		"ML_COMMENT",
		"EVENT",
		"INT",
		"MODETYPE",
		"WS"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	
	}
