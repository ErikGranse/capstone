/*
 * Mode.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Beat object that will be passed via the BeatEvent object. Creates static Beat
 * objects for easy reference.
 */

/**
 * An informational class, mode is used by the Device class. Static
 * instances of Mode are used to store the current operating mode
 * of the device
 * 
 * @author egranse
 */

public class Mode {

    private String mode;
    
    /** Creates a new instance of Beat */
    public Mode() {
    }
    
    /** Creates a new instance of Beat taking a string message as a parameter */
    private Mode(String mode) {
        this.mode = mode;
    }
    
    public static final Mode V00 = new Mode("V00");        
    public static final Mode VVI = new Mode("VVI");
    public static final Mode VVT = new Mode("VVT");

    /*Returns the message contained within the mode. Used by the listener if a
     *text output is desired.
     */
    public String toString() {
        return mode;
    }



}