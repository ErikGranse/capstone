/* This class acts like a controller between the script and the simulator. 
 * It reads in the input script file, gets it scanned & parsed and makes the 
 * appropriate changes to the device. 
 */
import java.io.*;

public class ProtocolController {
    String myFile = "";
    Device myDevice;

    // Constructor - gets an instance of the device & the input script file
    public ProtocolController(String aFile, Device aDevice) {
        myFile = aFile;
        myDevice = aDevice;
    }
    
    // method to run the script
    public void runScript() throws Exception {

        BufferedReader readScript = null;
        
        // get the script from the file
        try {
            readScript = new BufferedReader(new FileReader(myFile));
        } catch ( FileNotFoundException e ) {
            System.err.println("File not found or Could not open file!");
        }

        // create a scanner that reads from the buffered input from the script
        L lexer = new L(readScript);
        // create a parser that reads from the scanner
        P parser = new P(lexer);

        while ( readScript.ready() ) {
            parser.startRule(readScript, this); //start parsing at the startRule rule
        }

        readScript.close();
        System.out.println("End of script");
    } 

    // method to set the device pace rate to the new rate got from the script
    public void setDeviceRate(int rate) {
        // convert rate to interval
        float temp = (float) (60.0 / rate);
        int interval = (int) (temp * 1000);
        // set the device pace rate to the new rate
        myDevice.setDeviceEscapeInterval(interval); 
    }

    // method to set the device refractory interval to the new interval got from the script
    public void setRefractory(int interval) {
        myDevice.setDeviceRefractoryInterval(interval);
    } 

    // method to change the mode to the new mode got from the script
    public void changeMode(String myMode) {
        myDevice.setMode(myMode);
    } 

    // method to change the AV delay to the new avd got from the script
    public void setAVDelay(int avd) {
        //myDevice.setAVDelay(avd);
    } 

    // method to perform a specified action for count number of times
    public void setCount(String event, int count) {
        char chamber = event.charAt(0);
        char activity = event.charAt(1);

        //for (int i = count; i >= 1; i--) {
        // logic here - to be added
        //}
    }

}