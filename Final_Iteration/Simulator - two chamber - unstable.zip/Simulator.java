import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class Simulator implements ActionListener, ItemListener{
	volatile Ventricle myVentricle;
	volatile Atrium myAtrium;
	volatile Device myDevice;
	//Channel ventricleDevice, atriumDevice;
    HeartMonitor monitor;
	public JTextField ventricleChamberRefractoryInterval, avNodeEscapeInterval, prDelayInterval;
	public JTextField atriumChamberRefractoryInterval, saNodeEscapeInterval;
	public JTextField deviceEscapePace, deviceRefractoryInterval, deviceMaxPaceInterval, deviceMode;
    public JButton atriumUpdateButton, ventricleUpdateButton, deviceUpdateButton, runScript;
    private JCheckBox showHeart;
    private JPanel trace;
    private JPanel heartTrace;
    private JPanel atriumControls;
    private JPanel ventricleControls;
    private JPanel deviceControls;
    private GridBagConstraints c = new GridBagConstraints();
    private Thread threadScript;
    private Runnable runThreadsScript;
    private ProtocolController protocolController;
    private JFileChooser chooser;
    
	public Simulator(){
		myAtrium = new Atrium();
		myVentricle = new Ventricle(myAtrium);
		myDevice = new Device(myAtrium, myVentricle);
		//atriumDevice = new Channel(myAtrium, myAtrium);
		//ventricleDevice = new Channel(myVentricle, myVentricle);
		chooser = new JFileChooser();
	}

    public static void main(String[] args){
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private void buildUI(Container container) {
    	
        HeartMonitor heartMonitor = new HeartMonitor();
        Monitor monitor = new Monitor();
        
        myVentricle.chamber.addBeatListener(heartMonitor);
		
		heartTrace = new JPanel();
		heartTrace.setLayout(new BoxLayout(heartTrace, BoxLayout.PAGE_AXIS));
		heartTrace.add(heartMonitor);
		
		//trace holds the elements associated with displaying the output of the
		//simulation.
		trace = new JPanel();
		trace.setLayout(new BoxLayout(trace, BoxLayout.PAGE_AXIS));
		trace.add(new JLabel("Each grid square is approximately equal to 500ms:"));
		monitor.addTrace(myDevice.aChannel, trace);
		monitor.addTrace(myDevice.vChannel,trace);
		
	    //atriumControls contains the labels and fields necessary to control the
	    //heart object.
		atriumControls = new JPanel();
		atriumControls.setLayout(new BoxLayout(atriumControls, BoxLayout.PAGE_AXIS));
		atriumControls.setBorder(BorderFactory.createTitledBorder("Atrium Controls"));
		atriumControls.add(new JLabel("SA Escape Rate:"));
		atriumControls.add(saNodeEscapeInterval = new JTextField(4));
		atriumControls.add(new JLabel("Chamber Refractory Interval:"));
		atriumControls.add(atriumChamberRefractoryInterval = new JTextField(4));
		atriumControls.add(atriumUpdateButton = new JButton("Apply"), c);

		
		//ventricleControls contains the labels and fields necessary to control the
	    //heart object.
		ventricleControls = new JPanel();
		ventricleControls.setLayout(new BoxLayout(ventricleControls, BoxLayout.PAGE_AXIS));
		ventricleControls.setBorder(BorderFactory.createTitledBorder("Ventricle Controls"));
		ventricleControls.add(new JLabel("AV Escape Rate:"));
		ventricleControls.add(avNodeEscapeInterval = new JTextField(4));
		ventricleControls.add(new JLabel("PR Delay Interval:"));
		ventricleControls.add(prDelayInterval = new JTextField(4));
		ventricleControls.add(new JLabel("Chamber Refractory Interval:"));
		ventricleControls.add(ventricleChamberRefractoryInterval = new JTextField(4));
		ventricleControls.add(ventricleUpdateButton = new JButton("Apply"), c);
		
	    //deviceControls contains the labels and fields necessary to control the
	    //device object.
		deviceControls = new JPanel();
		deviceControls.setLayout(new BoxLayout(deviceControls, BoxLayout.PAGE_AXIS));
    	deviceControls.setBorder(BorderFactory.createTitledBorder("Channel Controls"));
		deviceControls.add(new JLabel("Escape Pace Rate:"));
		deviceControls.add(deviceEscapePace = new JTextField(4));
		deviceControls.add(new JLabel("Max Pace Rate:"));
		deviceControls.add(deviceMaxPaceInterval = new JTextField(4));
		deviceControls.add(new JLabel("Refractory Interval:"));
		deviceControls.add(deviceRefractoryInterval = new JTextField(4));
		deviceControls.add(new JLabel("Mode:"));
		deviceControls.add(deviceMode = new JTextField(4));
		deviceControls.add(deviceUpdateButton = new JButton("Apply"), c);
		deviceControls.add(runScript = new JButton("Run Script"), c);
		

        //Align the left edges of the components.
        heartMonitor.setAlignmentX(Component.LEFT_ALIGNMENT);
        
    	//container is the content pane; it holds all other elements.
        //Grid layout:
        //
        // ----------------------------------------------------------
        // |TRACE                                                   |
        // |--------------------------------------------------------|
        // |HEARTCONTROLS   |  DEVICE CONTROLS                      |
        // |--------------------------------------------------------|
        // |CHANGE BUTTON                                           |
        // ----------------------------------------------------------
        
    	container.setLayout(new GridBagLayout());

		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 3;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		container.add(heartTrace, c);
		
		c.gridx = 0;
		c.gridy = 1;
		container.add(trace, c);
		
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		container.add(atriumControls, c);
		
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		container.add(ventricleControls, c);
		
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		container.add(deviceControls, c);
		
		c.gridx = 0;
		c.gridy = 3;
		container.add(showHeart = new JCheckBox("Show heart trace"), c);
		showHeart.setSelected(true);
		
		saNodeEscapeInterval.setText(convertToRate(myAtrium.saNode.getSAEscapeInterval()) + "");
		atriumChamberRefractoryInterval.setText(myAtrium.chamber.getChamberRefractoryInterval() + "");
		
		ventricleChamberRefractoryInterval.setText(myVentricle.chamber.getChamberRefractoryInterval() + "");
		avNodeEscapeInterval.setText(convertToRate(myVentricle.avNode.getAVEscapeInterval()) + "");
		prDelayInterval.setText(myVentricle.avNode.getPRDelayInterval() + "");

		deviceEscapePace.setText(convertToRate(myDevice.getDeviceEscapeInterval()) + "");
		deviceRefractoryInterval.setText(myDevice.getDeviceRefractoryInterval() + "");
		deviceMaxPaceInterval.setText(myDevice.getDeviceMaxPaceInterval() + "");
		//deviceMode.setText(ventricleDevice.getMode());
		
		atriumUpdateButton.addActionListener(this);
		ventricleUpdateButton.addActionListener(this);
		deviceUpdateButton.addActionListener(this);
		showHeart.addItemListener(this);
		runScript.addActionListener(this);
        
    }


    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {


        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        Simulator controller = new Simulator();
        controller.buildUI(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e)
	{
    	if(e.getSource() == atriumUpdateButton)
	    {
	        myAtrium.chamber.setChamberRefractoryInterval(Integer.parseInt(atriumChamberRefractoryInterval.getText().trim()));
	        myAtrium.saNode.setSAEscapeInterval(convertToInterval(Integer.parseInt(saNodeEscapeInterval.getText().trim())));
	    }
    	else if(e.getSource() == ventricleUpdateButton)
	    {
	        myVentricle.chamber.setChamberRefractoryInterval(Integer.parseInt(ventricleChamberRefractoryInterval.getText().trim()));
	        myVentricle.avNode.setAVEscapeInterval(convertToInterval(Integer.parseInt(avNodeEscapeInterval.getText().trim())));
	        myVentricle.avNode.setPRDelayInterval(Integer.parseInt(prDelayInterval.getText().trim()));
	    }
	    else if(e.getSource() == deviceUpdateButton)
	    {
	        myDevice.setDeviceEscapeInterval(convertToInterval(Integer.parseInt(deviceEscapePace.getText().trim())));
	        myDevice.setDeviceRefractoryInterval(Integer.parseInt(deviceRefractoryInterval.getText().trim()));
	        myDevice.setDeviceMaxPaceInterval(convertToInterval(Integer.parseInt(deviceMaxPaceInterval.getText().trim())));
	        myDevice.setMode((String) deviceMode.getText().trim());
	        //atriumDevice.setChannelEscapeInterval(convertToInterval(Integer.parseInt(deviceEscapePace.getText().trim())));
	        //atriumDevice.setChannelRefractoryInterval(Integer.parseInt(deviceRefractoryInterval.getText().trim()));
	        //atriumDevice.setChannelMaxPaceInterval(convertToInterval(Integer.parseInt(deviceMaxPaceInterval.getText().trim())));
	        //atriumDevice.setModeAction((String) deviceMode.getText().trim());
	    }
	    else if(e.getSource() == runScript)
	    {
	    	try{
	    		File curDir = new File(new File(".").getCanonicalPath());
	    		chooser.setCurrentDirectory(curDir);
	    		int returnVal = chooser.showOpenDialog(null);
	    		if(returnVal == JFileChooser.APPROVE_OPTION) {
	    			System.out.println("You chose to open this file: ");
	    			String myFile = (String)(chooser.getSelectedFile().getName());
	    			//protocolController = new ProtocolController(myFile, ventricleDevice);
	    			try{
	    				runThreadsScript = new Runnable(){
	    					public void run(){
	    						runScript();
	    					}
	    				};
	    				threadScript = new Thread(runThreadsScript, "Run ");
	    				threadScript.start();
	    			}
	    			catch(Exception me){}
	    		}
	    	}
	    	catch(Exception p){}
	    }
	}

    public void runScript(){
    	try{
    		protocolController.runScript();
    	}
    	catch(Exception why){}
    }
    
    public void itemStateChanged(ItemEvent e){
    	
        if (e.getItemSelectable() == showHeart) {
        	if (e.getStateChange() == ItemEvent.DESELECTED){
        		heartTrace.setVisible(false);
        	}
        	else{
        		heartTrace.setVisible(true);
        	}
        }
    }
    
    public int convertToInterval(int rate){
    	int interval;
    	float temp = (float)(60.0 / rate);
    	interval = (int)(temp * 1000);
    	return interval;
    }
    
    public int convertToRate(int interval){
    	int rate;
    	float temp = (float)(60000 / interval);
    	rate = (int)(temp);
    	return rate;
    }
}


