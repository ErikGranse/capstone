
public class SANode{
	private Chamber myChamber;
	public Thread saEscapeThread;
	private Runnable runSAEscapeThread;
	private volatile int saEscapeInterval = 750; //750ms = 80bpm

	public SANode(Chamber newChamber){
		myChamber = newChamber;
		runSAEscapeThread = new Runnable(){
			public void run(){
				runSAInterval();
			}
		};
		saEscapeThread = new Thread(runSAEscapeThread, "saEscapeThread");
		saEscapeThread.start();
	}
	
	public void runSAInterval(){
		while(true){
			try{
				while(true){
					saEscapeThread.sleep(saEscapeInterval);
					if(!myChamber.inRefract())
						break;
				}

			}
			catch(Exception e){ }
			if(!myChamber.inRefract()){
				System.out.println("Hi!");
				beat();
			}
		}
	}

	public void beat(){
		if(!myChamber.inRefract()){
			myChamber.setRefractory();
			myChamber.beat();
		}
	}
	
	public synchronized void setSAEscapeInterval(int newTime){
		saEscapeInterval = newTime;
	}
	
	public synchronized int getSAEscapeInterval()	{
		return saEscapeInterval;
	}

}