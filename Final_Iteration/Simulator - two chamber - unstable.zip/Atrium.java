/**
 * The atrium creates an SANode and a chamber; it provides visibility
 * to external classes as well.
 */

public class Atrium implements HeartConstruct{
	protected SANode saNode;
	protected Chamber chamber;
	
	public Atrium()	{
		chamber = new Chamber();
		saNode = new SANode(chamber);
	}
	
	public boolean inRefract(){
		return chamber.inRefract();
	}
	
	public void beat(){
		if(!inRefract()){
			saNode.saEscapeThread.interrupt();
			chamber.setRefractory();
			chamber.beat();
		}
	}
	
	public void addBeatListener(BeatListener bl){
		chamber.addBeatListener(bl);
	}
	
	public void removeBeatListener(BeatListener bl){
		chamber.removeBeatListener(bl);
	}
}