
public interface HeartConstruct {
	
	public void beat();
	public void addBeatListener(BeatListener bl);
	public void removeBeatListener(BeatListener bl);
}
