import java.util.*;

public class Channel implements BeatListener{
    private Pace pace;
    private ModeAction modeAction;
    
    private List listeners = new ArrayList();
	
    //channelInRefractory is a flag used to suppress multiple senses in the
    //channelRefractoryInterval.
    private boolean channelInRefractory = false;
    
    //inEscapePacing is a flag used to determine whether the
    //channelPrimaryPaceThread loops (escape modeAction) or is a single run.
     private boolean inEscapePacing = true;	
    
    //inMaxPaceInterval is a flag used to suppress primary paces while in the
    //channelMaxPaceInterval.
    private boolean inMaxPaceInterval = false;
    
    //resetBySense is a flag used to suppress primary paces when the 
    //channelPrimaryPaceThread is interrupted by a sense event.
	private boolean resetBySense = false;
	
	//maxRatePace is a flag used to store whether a primary pace has been
	//throttled via the channelMaxPaceThread.
	private boolean maxRatePace = false;
	
	//maxRatePace is a flag used to store whether a primary pace has been
	//triggered via a sense.
	private boolean triggeredPace = false;
	
	//inPacedWindow is a flag used to determine whether a sense was intrinsic
	//or due to a device pace.
	private boolean inPacedWindow = false;
	
	private volatile int channelEscapeInterval = 1000;  //1000ms = 60bpm
	private volatile int channelAVDelayInterval = 100; //ms
	private volatile int channelRefractoryInterval = 100; //ms
	private volatile int channelMaxPaceInterval = 400; // 400ms = 150 BPM
	private volatile int channelPacedSenseWindow = 10; //ms
	
	private HeartConstruct myPaceChamber;
	private HeartConstruct mySenseChamber;
	private Thread channelPrimaryPaceThread, channelRefractoryThread, channelMaxPaceThread, channelPacedSenseThread;
	private Runnable runChannelPrimaryPace, runChannelRefractory, runMaxPace, runChannelPaced;
	

	public Channel(HeartConstruct paceChamber, HeartConstruct senseChamber){

		modeAction = ModeAction.I;
		
		runChannelPrimaryPace = new Runnable(){
			public void run(){
				devicePace();
			}
		};
		
		runChannelRefractory = new Runnable(){
			public void run(){
				startDeviceRefractory();
			}
		};
		
		runMaxPace = new Runnable(){
			public void run(){
				startMaxPaceInterval();
			}
		};
		
		runChannelPaced = new Runnable(){
			public void run(){
				startPacedWindow();
			}
		};
		
		//The senseChamber may be null; this allows the channel to
		//operate in x00 modeAction.
		if(senseChamber != null){
			mySenseChamber = senseChamber;
			mySenseChamber.addBeatListener(this);
		}

		//if the pace chamber is null, the device will do nothing but report
		//senses (if the sense chamber is not null).
		if(paceChamber != null){
			myPaceChamber = paceChamber;
			channelPrimaryPaceThread = new Thread(runChannelPrimaryPace, "channelPrimaryPaceThread");
			channelPrimaryPaceThread.start();
		}
	}

	public void devicePace(){
		do{
			try{
				while(true){
					if(inEscapePacing)
						channelPrimaryPaceThread.sleep(channelEscapeInterval);
					else{
						System.out.println("************************");
						channelPrimaryPaceThread.sleep(channelAVDelayInterval);
					}
					if(inMaxPaceInterval)
						maxRatePace = true;
					else break;
				}
			}
			catch(Exception e){ }
			
			if((modeAction == ModeAction.T && triggeredPace) || (!inMaxPaceInterval && !resetBySense)){
				if(maxRatePace){
					pace = Pace.MAX_PACE;
					maxRatePace = false;
				}
				else if(triggeredPace){
					pace = Pace.TRIGGERED_PACE;
					triggeredPace = false;
				}
				else
					pace = Pace.ESC_PACE;
				firePaceEvent();
				deviceBeat();
			}
			 resetBySense = false;
		}while(inEscapePacing);
	}
	
	public void deviceBeat(){
		inPacedWindow = true;
		channelPacedSenseThread = new Thread(runChannelPaced, "Paced Sense Thread");
		channelPacedSenseThread.start();
		try{
			myPaceChamber.beat();
		}
		catch(NullPointerException e){}
	
		inMaxPaceInterval = true;
		channelMaxPaceThread = new Thread(runMaxPace, "MaxPaceRateThread");
		channelMaxPaceThread.start();
	}
	
	public void startMaxPaceInterval(){
		try{
			channelMaxPaceThread.sleep(channelMaxPaceInterval);
		}
		catch(Exception e){}
		inMaxPaceInterval = false;
		if(maxRatePace){
			channelPrimaryPaceThread.interrupt();
		}
	}

	public void deviceRefractory(){
		channelRefractoryThread = new Thread(runChannelRefractory, "threaddeviceRefractoryThread");
		channelRefractoryThread.start();
	}

	public void startDeviceRefractory(){
		try{
			pace = Pace.R_START;
			firePaceEvent();
			channelRefractoryThread.sleep(channelRefractoryInterval);
			pace = Pace.R_END;
			firePaceEvent();
			channelInRefractory = false;
		}
		catch(Exception e){ }
	}
	
    public void beatSensed(BeatEvent event) {
       if(event.beat == Beat.BEAT && modeAction != ModeAction.O){
    	   if(!channelInRefractory){
    		   resetBySense = true;
    		   channelPrimaryPaceThread.interrupt();
    	   }
    	   channelInRefractory = true;
    	   deviceRefractory();
    	   if(inPacedWindow) pace = Pace.PACED_SENSE;
    	   else pace = Pace.INTRINSIC_SENSE;
    	   firePaceEvent();
    	   if(modeAction == ModeAction.T){
    		   triggeredPace = true;
    		   channelPrimaryPaceThread.interrupt();
    	   }
       }
    }
    
    public void startPacedWindow(){
    	try{
    		channelPacedSenseThread.sleep(channelPacedSenseWindow);
    	}
    	catch(Exception e){}
    	inPacedWindow = false;
    }

	public synchronized void setModeAction(String newModeAction){
		if(newModeAction == "O"){
			modeAction = ModeAction.O;
		}
		else if(newModeAction == "I"){
			modeAction = ModeAction.I;
		}
		else if(newModeAction == "T"){
			modeAction = ModeAction.T;
		}
	}
	
	public synchronized String getModeAction(){
		return modeAction.toString();
	}
	
	public synchronized void setPaceChamber(HeartConstruct paceChamber){
		if(paceChamber == null){
			myPaceChamber = null;
			inEscapePacing = false;
		}
		else{
			myPaceChamber = paceChamber;
			if(!channelPrimaryPaceThread.isAlive()){
				System.out.println("Starting pace thread");
				channelPrimaryPaceThread = new Thread(runChannelPrimaryPace, "channelPrimaryPaceThread");
				channelPrimaryPaceThread.start();
			}
		}
	}
	
	public synchronized void setSenseChamber(HeartConstruct senseChamber){
		if(mySenseChamber != null){
			mySenseChamber.removeBeatListener(this);
			mySenseChamber = null;
		}
		if(senseChamber != null){
			mySenseChamber = senseChamber;
			mySenseChamber.addBeatListener(this);
		}
	}
	
	public synchronized void setChannelEscapeInterval(int newTime){
		channelEscapeInterval = newTime;
	}
	
	public synchronized int getChannelEscapeInterval(){
		return channelEscapeInterval;
	}

	public synchronized void setChannelRefractoryInterval(int newTime){
		channelRefractoryInterval = newTime;
	}
	
	public synchronized int getChannelRefractoryInterval(){
		return channelRefractoryInterval;
	}
	
	public synchronized void setChannelMaxPaceInterval(int newTime){
		channelMaxPaceInterval = newTime;
	}
    
	public synchronized int getChannelMaxPaceInterval(){
		return channelMaxPaceInterval;
	}
	
	public synchronized void setInEscapePacing(boolean doEscape){
		if(doEscape)inEscapePacing = true;
		else inEscapePacing = false;
	}
	
	public synchronized void addPaceListener(PaceListener pl) {
        listeners.add(pl);
    }

    //Removes a listener from the listener list.
    public synchronized void removePaceListener(PaceListener pl) {
        listeners.remove(pl);
    }

    //Loops through all listeners and pushes the paceEvent to them.
    private synchronized void firePaceEvent() {
        PaceEvent paceEvent = new PaceEvent(this, pace);
        Iterator listenerIterator = listeners.iterator();
        while ( listenerIterator.hasNext() ) {
            ((PaceListener) listenerIterator.next()).paceSensed(paceEvent);
        }
    }
}
