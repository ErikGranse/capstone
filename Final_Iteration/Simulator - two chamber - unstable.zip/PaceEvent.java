/*
 * PaceEvent.java
 *
 * Created on June 20, 2005, 10:13 PM
 *
 * This is the object that will be returned to the listener; it contains a reference
 * to the source object and a pace object that will expose the type of pace event.
 */

/**
 *
 * @author egranse
 */

import java.util.EventObject;

public class PaceEvent extends EventObject {

    public Pace pace;
    public Channel source;

    public PaceEvent(Channel source, Pace pace) {
        super(source);
        this.source = source;
        this.pace = pace;
    }

    public Pace pace() {
        return pace;
    }
    
    public Object getSource(){
    	return source;
    }

}
