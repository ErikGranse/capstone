/*
 * Pace.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Pace object that will be passed via the PaceEvent object. Creates static Pace
 * objects for easy reference.
 */

/**
 * A messaging class, pace is used in the PaceEvent class. Static
 * instances of Pace are used to provide the type of event and 
 * necessary text messages.
 * 
 * @author egranse
 */

public class Pace {
    private String pace;

    /** Creates a new instance of Pace */
    public Pace() {
    }

    /** Creates a new instance of Pace taking a string message as a parameter */
    private Pace(String pace) {
        this.pace = pace;
    }

    public static final Pace ESC_PACE = new Pace("Escape Pace Sensed");
    public static final Pace TRIGGERED_PACE = new Pace("Triggered pace sensed");
    public static final Pace MAX_PACE = new Pace("Max rate pace sensed");
    public static final Pace R_START = new Pace("Channel Refractory started");
    public static final Pace R_END = new Pace("Channel Refractory ended");
    public static final Pace INTRINSIC_SENSE = new Pace("Intrinsic beat sensed");
    public static final Pace PACED_SENSE = new Pace("Paced beat sensed");
    
    /*Returns the message contained within the pace. Used by the listener if a
     *text output is desired.
     */
    public String toString() {
        return pace;
    }



}
