/**
 * The ventricle creates an AVNode and a chamber; it provides visibility
 * to external classes as well.
 */

public class Ventricle implements HeartConstruct{
	protected AVNode avNode;
	protected Chamber chamber;
	
	/*This constructor is for a single-chamber simulation;
	 * the ventricle will run on its own.
	 */
	public Ventricle()	{
		chamber = new Chamber();
		avNode = new AVNode(chamber);
	}
	
	/*This constructor is used in a multi-chamber model; it 
	 * accepts an atrium for the AVNode to listen to for pacing.
	 */
	public Ventricle(Atrium atrium)	{
		chamber = new Chamber();
		avNode = new AVNode(chamber);
		atrium.chamber.addBeatListener(avNode);
	}
	
	public boolean inRefract(){
		return chamber.inRefract();
	}
	
	public void beat(){
		if(!inRefract()){
			avNode.avEscapeThread.interrupt();
			chamber.setRefractory();
			chamber.beat();
		}
	}
	
	public void addBeatListener(BeatListener bl){
		chamber.addBeatListener(bl);
	}
	
	public void removeBeatListener(BeatListener bl){
		chamber.removeBeatListener(bl);
	}
}