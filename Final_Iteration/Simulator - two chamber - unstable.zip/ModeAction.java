/*
 * ModeAction.java
 *
 * Created on June 20, 2005, 10:09 PM
 *
 * Beat object that will be passed via the BeatEvent object. Creates static Beat
 * objects for easy reference.
 */

/**
 * An informational class, mode is used by the Channel class. Static
 * instances of Mode are used to store the current operating mode
 * of the device
 * 
 * @author egranse
 */

public class ModeAction {

    private String mode;
    
    public ModeAction() {
    }
    
    private ModeAction(String mode) {
        this.mode = mode;
    }
    
    public static final ModeAction O = new ModeAction("0");        
    public static final ModeAction I = new ModeAction("I");
    public static final ModeAction T = new ModeAction("T");

}