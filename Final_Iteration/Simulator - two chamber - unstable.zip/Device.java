import java.util.Iterator;

public class Device implements PaceListener{
	protected Channel aChannel, vChannel;
	private Mode mode;
	private HeartConstruct atrium, ventricle;
	
	private volatile int deviceEscapeInterval = 1000;  //1000ms = 60bpm
	private volatile int deviceRefractoryInterval = 100;
	private volatile int deviceMaxPaceInterval = 400; // 400ms = 150 BPM
	
	public Device(HeartConstruct atrium, HeartConstruct ventricle){
		aChannel = new Channel(atrium, atrium);
		vChannel = new Channel(ventricle, ventricle);
		this.atrium = atrium;
		this.ventricle = ventricle;
		aChannel.addPaceListener(this);
		vChannel.addPaceListener(this);
	}
	
	public void setMode(String newMode){
		if(newMode.equals("V00")){
			mode = Mode.V00;
			aChannel.setPaceChamber(null);
			aChannel.setSenseChamber(null);
			aChannel.setModeAction("O");
			aChannel.setInEscapePacing(false);
			vChannel.setPaceChamber(ventricle);
			vChannel.setSenseChamber(null);
			vChannel.setModeAction("O");
			vChannel.setInEscapePacing(true);
		}
		else if(newMode.equals("A00")){
			mode = Mode.A00;
			aChannel.setPaceChamber(atrium);
			aChannel.setSenseChamber(null);
			aChannel.setModeAction("O");
			aChannel.setInEscapePacing(true);
			vChannel.setPaceChamber(null);
			vChannel.setSenseChamber(null);
			vChannel.setModeAction("O");
			vChannel.setInEscapePacing(false);
		}
		else if(newMode.equals("VVI")){
			mode = Mode.VVI;
			aChannel.setPaceChamber(null);
			aChannel.setSenseChamber(null);
			aChannel.setModeAction("O");
			aChannel.setInEscapePacing(false);
			vChannel.setPaceChamber(ventricle);
			vChannel.setSenseChamber(ventricle);
			vChannel.setModeAction("I");
			vChannel.setInEscapePacing(true);
		}
		else if(newMode.equals("VVT")){
			mode = Mode.VVT;
			aChannel.setPaceChamber(null);
			aChannel.setSenseChamber(null);
			aChannel.setModeAction("O");
			aChannel.setInEscapePacing(false);
			vChannel.setPaceChamber(ventricle);
			vChannel.setSenseChamber(ventricle);
			vChannel.setModeAction("T");
			vChannel.setInEscapePacing(true);
		}
		else if(newMode.equals("AAI")){
			mode = Mode.AAI;
			aChannel.setPaceChamber(atrium);
			aChannel.setSenseChamber(atrium);
			aChannel.setModeAction("I");
			aChannel.setInEscapePacing(true);
			vChannel.setPaceChamber(null);
			vChannel.setSenseChamber(null);
			vChannel.setModeAction("O");
			vChannel.setInEscapePacing(false);
		}
		else if(newMode.equals("AAT")){
			mode = Mode.AAT;
			aChannel.setPaceChamber(atrium);
			aChannel.setSenseChamber(atrium);
			aChannel.setModeAction("T");
			aChannel.setInEscapePacing(true);
			vChannel.setPaceChamber(null);
			vChannel.setSenseChamber(null);
			vChannel.setModeAction("O");
			vChannel.setInEscapePacing(false);
		}
		else if(newMode.equals("DDD")){
			mode = Mode.DDD;
			aChannel.setPaceChamber(atrium);
			aChannel.setSenseChamber(atrium);
			aChannel.setModeAction("I");
			aChannel.setInEscapePacing(true);
			vChannel.setPaceChamber(ventricle);
			vChannel.setSenseChamber(ventricle);
			vChannel.setModeAction("I");
			vChannel.setInEscapePacing(false);
		}
	}
	
	public void paceSensed(PaceEvent e){
		if(e.getSource().equals(aChannel)){
			System.out.println("Atrium " + e.pace.toString());
			if(mode == Mode.DDD && (e.pace == Pace.INTRINSIC_SENSE || e.pace ==Pace.TRIGGERED_PACE)){
				System.out.println("-----------------------------");
				vChannel.devicePace();
			}
		}
		else if(e.getSource().equals(vChannel)){
			System.out.println("Ventricle " + e.pace.toString());
		}
	}
	
	public synchronized void setDeviceEscapeInterval(int newTime){
		deviceEscapeInterval = newTime;
		aChannel.setChannelEscapeInterval(newTime);
		vChannel.setChannelEscapeInterval(newTime);
	}
	
	public synchronized int getDeviceEscapeInterval(){
		return deviceEscapeInterval;
	}

	public synchronized void setDeviceRefractoryInterval(int newTime){
		deviceRefractoryInterval = newTime;
		aChannel.setChannelRefractoryInterval(newTime);
		vChannel.setChannelRefractoryInterval(newTime);
	}
	
	public synchronized int getDeviceRefractoryInterval(){
		return deviceRefractoryInterval;
	}
	
	public synchronized void setDeviceMaxPaceInterval(int newTime){
		deviceMaxPaceInterval = newTime;
		aChannel.setChannelMaxPaceInterval(newTime);
		vChannel.setChannelMaxPaceInterval(newTime);
	}
    
	public synchronized int getDeviceMaxPaceInterval(){
		return deviceMaxPaceInterval;
	}
	
/*	public synchronized void addPaceListener(PaceListener pl) {
        listeners.add(pl);
    }

    //Removes a listener from the listener list.
    public synchronized void removePaceListener(PaceListener pl) {
        listeners.remove(pl);
    }

    //Loops through all listeners and pushes the paceEvent to them.
    private synchronized void firePaceEvent() {
        PaceEvent paceEvent = new PaceEvent(this, pace);
        Iterator listenerIterator = listeners.iterator();
        while ( listenerIterator.hasNext() ) {
            ((PaceListener) listenerIterator.next()).paceSensed(paceEvent);
        }
    }
*/
}
